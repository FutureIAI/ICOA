from small_work import data_deal
from fjsp import FJSP
from multi_opt import mul_op
import numpy as np

import random
import math
from pymoo.indicators.hv import Hypervolume
# import matplotlib.pyplot as plt

import matplotlib.pyplot as plt
# from matplotlib.pylab import mpl
# mpl.rcParams['font.sans-serif'] = ['SimHei']  # 添加这条可以让图形显示中文

class ema():
    def __init__(self,generation,popsize,to,oh,work,job_num,tran_time,M_dicr,all_num,Tmachine,Tmachinetime,work_arr):
        self.generation = generation  # 迭代次数
        self.popsize = popsize  # 种群规模
        self.to = to
        self.oh = oh
        self.work = work
        self.job_num = job_num                  # 种群规模
        self.tran_time=tran_time
        self.M_dicr=M_dicr
        self.all_num=all_num
        self.Tmachine=Tmachine
        self.Tmachinetime=Tmachinetime
        self.work_arr = work_arr
        # print(self.job_num)
    def to_MT(self,W1,M1,T1,R1,WC): #把加工机器编码和加工时间编码转化为对应列表，目的是记录工件的加工时间和加工机器

        OS_dic=[]

        for i in range(self.job_num):#添加工件个数的空列表
            OS_dic.append([])
        # print(OS_dic)
        for i in range(self.job_num):

            for j in range(len(W1[0])):
                if W1[0][j]==i:
                    OS_dic[i].append([M1[0][j],T1[0][j],R1[0][j],WC[0][j]])
        # print(OS_dic)

        return OS_dic
    def back_MT(self,J,OS):  #列表返回机器及加工时间编码
        m1,t1,r1,wc =np.zeros((1,self.all_num)),np.zeros((1,self.all_num)),np.zeros((1,self.all_num)),np.zeros((1,self.all_num))
        for i in range(self.job_num):
            indx=0
            for j in range(self.all_num):
                if J[0][j]==i:
                    m1[0][j] = OS[i][indx][0]
                    t1[0][j] = OS[i][indx][1]
                    r1[0][j] = OS[i][indx][2]
                    wc[0][j] = OS[i][indx][3]
                    indx+=1
        return m1,t1,r1,wc
    def MOX(self,J1,J2):
        a,b=random.sample(range(0, self.all_num), 2)
        wh1,wh2=[],[]
        J3=np.copy(J2)
        er1,er2=np.zeros((1,self.all_num)),np.zeros((1,self.all_num))
        if a>b:
            a,b=b,a
        change=np.copy(J1[0][a:b+1])
        #子代1
        for i in range(len(change)):
            for j in range(len(J2[0])):
                if change[i]==J2[0][j]:
                    wh1.append(i+a)#J1的点位
                    wh2.append(j)#J2的点位
                    J2[0][j]=-1
                    break
        wh2.sort()
        for z in range(len(wh1)):
            er1[0][wh2[z]]=J1[0][wh1[z]]
        for k in range(len(J2[0])):
            if J2[0][k]>=0:
                er1[0][k]=J2[0][k]
        #子代2
        wh1, wh2 = [], []
        change = np.copy(J3[0][a:b + 1])
        for i in range(len(change)):
            for j in range(len(J1[0])):
                if change[i]==J1[0][j]:
                    wh1.append(i+a)#J2的点位
                    wh2.append(j)#J1的点位
                    J1[0][j]=-1
                    break
        wh2.sort()
        for z in range(len(wh1)):
            er2[0][wh2[z]]=J3[0][wh1[z]]
        for k in range(len(J1[0])):
            if J1[0][k]>=0:
                er2[0][k]=J1[0][k]
        return er1,er2
    def ISM(self,J):
        a, b = random.sample(range(0, self.all_num), 2)
        if a>b:
            a,b=b,a
        JR=J[0][a:b+1]
        JR1=JR[::-1]
        J[0][a:b+1]=JR1
        return J
    def RMM(self,J,M,T,TR,W):
        a, b = random.sample(range(0, self.all_num), 2)
        x=[a,b]

        for k in x:
            indx=0
            for i in range(self.all_num):
                if J[0][i]==J[0][k]:
                    indx+=1
                    # print("hfdjshf",indx)
                    if i==k :
                        choose=np.copy(self.Tmachine[int(J[0][k])][indx-1])
                        choose1 = np.copy(self.Tmachinetime[int(J[0][k])][indx - 1])
                        ind=np.argwhere(choose==M[0][k]+1)
                        np.delete(choose,ind[0][0])
                        np.delete(choose1,ind[0][0])
                        c1=min(choose1)
                        ind1=np.argwhere(choose1==c1)
                        c2=choose[ind1[0][0]]-1
                        M[0][k]=c2
                        T[0][k]=c1
                        W[0][k] =np.random.choice(self.work_arr[c2])
                        if indx==1:
                            TR[0][k]=0
                            for j in range(k,self.all_num):
                                if J[0][j]==J[0][k]:
                                    fa1=self.M_dicr[M[0][j]][0]-1
                                    fa2=self.M_dicr[M[0][k]][0]-1
                                    # print(fa1,"...",fa2)
                                    TR[0][j]=self.tran_time[fa2][fa1]
                                    # print(TR[0][j])
                                break
                        if indx>1:
                            indxx=0
                            for j in range(self.all_num):
                                indxx+=1
                                if J[0][j]==J[0][k] and indxx==indx-1 :
                                    fa1=self.M_dicr[M[0][j]][0]-1
                                    fa2 = self.M_dicr[M[0][k]][0]-1
                                    TR[0][j] = self.tran_time[fa1][fa2]
                                if J[0][j]==J[0][k] and indxx==indx+1 :
                                    fa1 = self.M_dicr[M[0][j]][0]-1
                                    fa2 = self.M_dicr[M[0][k]][0]-1
                                    TR[0][j] = self.tran_time[fa2][fa1]
                            break
                        break

        return J,M,T,TR,W
    def get_c(self,job,ma,time, tr, indxx,list_t,end,k):

        job.insert(0,list_t[end][k][0])
        indxx.insert(0,list_t[end][k][1])
        ma.insert(0,end)
        time.insert(0,list_t[end][k][3])
        tr.insert(0,list_t[end][k][4])
        if list_t[end][k][1]==1 and list_t[end][k][2]!=0:
            job,ma,time, tr, indxx=self.get_c(job,ma,time, tr, indxx,list_t,end,k-1)
            # print(1)

        elif list_t[end][k][1]!=1 and list_t[end][k-1][0]==list_t[end][k][0] and list_t[end][k][2]!=0:
            job, ma, time, tr, indxx = self.get_c(job, ma, time, tr, indxx, list_t, end, k - 1)

        elif list_t[end][k][1]!=1 and list_t[end][k-1][0]!=list_t[end][k][0] and list_t[end][k][2]!=0:
            for i in range(len(list_t)):
                for j in range(len(list_t[i])):
                    if list_t[i][j][0]==list_t[end][k][0] and list_t[i][j][1]==list_t[end][k][1]-1:
                        job, ma, time, tr, indxx = self.get_c(job, ma, time, tr, indxx, list_t, i, j)
        # elif list_t[end][k][2]==0:

        return job,ma,time, tr, indxx


    def ema_total(self):
        answer = []
        answer1=[]
        fit_every = [[], [], [], []]
        work_wc = np.zeros((self.popsize, len(self.work)))
        work_wc1 = np.zeros((self.popsize, len(self.work)))
        work_wc2 = np.zeros((self.popsize, len(self.work)))
        work_tran1,work_job1,work_M1,work_T1=np.zeros((self.popsize,len(self.work))),np.zeros((self.popsize,len(self.work))),np.zeros((self.popsize,len(self.work))),np.zeros((self.popsize,len(self.work)))
        work_tran2, work_job2, work_M2, work_T2 = np.zeros((self.popsize, len(self.work))), np.zeros((self.popsize, len(self.work))), np.zeros((self.popsize, len(self.work))), np.zeros((self.popsize, len(self.work)))
        # work_tran,work_job,work_M,work_T=np.zeros((self.popsize,len(self.work))),np.zeros((self.popsize,len(self.work))),np.zeros((self.popsize,len(self.work))),np.zeros((self.popsize,len(self.work)))
        # job_tran=np.zeros((self.popsize,len(self.work)))
        for gen in range(self.generation):#迭代次数100
            if(gen<1):                      #第一次生成多个可行的工序编码，机器编码，时间编码
                #种群规模100
                work_job, work_M, work_T, work_tran, work_F,job_init,work_wc=self.to.creat_job()
                for i in range(self.popsize):
                    list_T, list_M, list_S, list_W, tmmw = self.to.caculate(work_job[i:i+1], work_M[i:i+1], work_T[i:i+1], work_tran[i:i+1],work_wc[i:i+1])
                    C_finish, Twork, E_all, _, _, _, _ ,_= self.to.sig(list_T, list_M, list_S, list_W,
                                                                       work_job[i:i + 1], tmmw, work_tran[i:i + 1])


                    answer.append([C_finish,Twork,E_all])

                    # work_tran[i],work_job[i],work_M[i],work_T[i]=self.trantime[0],job[0],machine[0],machine_time[0]
                    # job_init[i]=initial_a\


                answer1=answer.copy()
                # print("jdhfgj", answer1)
                #OS交叉
                for i in range(0,self.popsize,2):
                    # print(work_job)
                    # print(work_job[i:i + 1])
                    job, machine, machine_time ,trantime,wc= np.copy(work_job[i:i + 1]),np.copy(work_M[i:i + 1]), np.copy(work_T[i:i + 1]),np.copy(work_tran[i:i + 1]),np.copy(work_wc[i:i + 1])
                    job1, machine1, machine_time1,trantime1 ,wc1=np.copy( work_job[i + 1:i + 2]),np.copy( work_M[i + 1:i + 2]), np.copy(work_T[i + 1:i + 2]),np.copy(work_tran[i + 1:i + 2]),np.copy(work_wc[i+1:i + 2])
                    OS_dic = self.to_MT(job, machine, machine_time, trantime,wc)
                    OS_dic1= self.to_MT(job1, machine1, machine_time1, trantime1,wc1)
                    job_new,job_new1=self.MOX(job,job1)
                    machine_new,time_new,tran_new,wc_new=self.back_MT(job_new,OS_dic)
                    # print(job_new)
                    list_T, list_M, list_S, list_W, tmmw = self.to.caculate(job_new, machine_new, time_new,tran_new,wc_new)
                    C_finish, Twork, E_all, _, _, _, _,_ = self.to.sig(list_T, list_M, list_S, list_W, job_new, tmmw,
                                                                       tran_new)
                    work_job1[i]=job_new
                    work_M1[i]=machine_new
                    work_T1[i]=time_new
                    work_tran1[i]=tran_new
                    work_wc1[i] = wc_new
                    answer1.append([C_finish, Twork, E_all])
                    machine_new1, time_new1, tran_new1 ,wc_new1 = self.back_MT(job_new1, OS_dic1)
                    list_T, list_M, list_S, list_W, tmmw = self.to.caculate(job_new1, machine_new1, time_new1, tran_new1,wc_new1)
                    C_finish, Twork, E_all, _, _, _, _ ,_= self.to.sig(list_T, list_M, list_S, list_W, job_new1, tmmw,
                                                                       tran_new1)
                    work_job1[i+1] = job_new1
                    work_M1[i+1] = machine_new1
                    work_T1[i+1] = time_new1
                    work_tran1[i+1] = tran_new1
                    work_wc1[i+1] = wc_new1
                    answer1.append([C_finish, Twork, E_all])
                    # print(job_new1)
                    # print(work_job1)

                #变异
                for i in range(self.popsize):
                    job, machine, machine_time, trantime,wc = np.copy(work_job[i:i + 1]), np.copy(work_M[i:i + 1]), np.copy(work_T[i:i + 1]),np.copy(work_tran[i:i + 1]),np.copy(work_wc[i:i + 1])
                    # print(machine)
                    O_dic = self.to_MT(job, machine, machine_time, trantime,wc)
                    p=random.random()
                    if p<=0.5:
                        # print(self.ISM(job))
                        j_new=self.ISM(job)
                        m_new,t_new,tr_new,w_new=self.back_MT(j_new,O_dic)
                        work_job2[i]=j_new[0]
                        work_M2[i]=m_new[0]
                        work_T2[i]=t_new[0]
                        work_tran2[i]=tr_new[0]
                        work_wc2[i] = w_new[0]
                        list_T, list_M, list_S, list_W, tmmw = self.to.caculate(j_new, m_new, t_new,tr_new,w_new)
                        C_finish, Twork, E_all, _, _, _, _ ,_= self.to.sig(list_T, list_M, list_S, list_W, j_new, tmmw,
                                                                           tr_new)
                        answer1.append([C_finish, Twork, E_all])
                        # print(m_new)

                    else:
                        j_new,m_new,t_new,tr_new,w_new = self.RMM(job,machine,machine_time,trantime,wc)
                        # print(j_new)
                        m_new, t_new, tr_new,w_new = self.back_MT(j_new, O_dic)
                        work_job2[i] = j_new
                        work_M2[i] = m_new
                        work_T2[i] = t_new
                        work_tran2[i] = tr_new
                        work_wc2[i] = w_new
                        list_T, list_M, list_S, list_W, tmmw = self.to.caculate(j_new, m_new, t_new, tr_new,w_new)
                        C_finish, Twork, E_all, _, _, _, _,_ = self.to.sig(list_T, list_M, list_S, list_W, j_new, tmmw,
                                                                           tr_new)
                        answer1.append([C_finish, Twork, E_all])

                R_job,R_m,R_t,R_tr,R_wc= np.concatenate((work_job, work_job1)),np.concatenate((work_M, work_M1)),np.concatenate((work_T, work_T1)),np.concatenate((work_tran, work_tran1)),np.concatenate((work_wc, work_wc1))
                R_job,R_m,R_t,R_tr,R_wc= np.concatenate((R_job, work_job2)),np.concatenate((R_m, work_M2)),np.concatenate((R_t, work_T2)),np.concatenate((R_tr, work_tran2)),np.concatenate((R_wc, work_wc2))

                front, crowd, crowder = self.oh.dis(answer1)  # 计算分层，拥挤度，种群排序结果
                prob=int(len(crowder)*0.15)
                crowder=crowder[0:self.popsize]
                # print(crowder)
                answer11=[]
                R1_job,R1_m,R1_t,R1_tr,R1_wc=np.zeros((self.popsize,len(self.work))),np.zeros((self.popsize,len(self.work))),np.zeros((self.popsize,len(self.work))),np.zeros((self.popsize,len(self.work))),np.zeros((self.popsize,len(self.work)))
                for i in range(self.popsize):
                    # print(i)
                    # print(crowder[i])
                    R1_job[i]=R_job[crowder[i]]
                    R1_m[i]=R_m[crowder[i]]
                    R1_t[i] = R_t[crowder[i]]
                    R1_tr[i] = R_tr[crowder[i]]
                    R1_wc[i] = R_wc[crowder[i]]
                    answer11.append(answer1[crowder[i]])
                front, crowd, crowder = self.oh.dis(answer11)
                # print(crowder)
                signal = front[0]
                # print(signal)
                pareto = np.array(answer)[signal].tolist()
                pareto_job, pareto_machine, pareto_time , pareto_wc = R1_job[signal], R1_m[signal], R1_t[signal],R1_wc[signal]
                x = [pareto[i][0] for i in range(len(pareto))]
                y = [pareto[i][1] for i in range(len(pareto))]
                z = [pareto[i][2] for i in range(len(pareto))]
                fit_every[3].append(gen)
                fit_every[0].append([min(x)])
                fit_every[1].append([max(y)])
                fit_every[2].append([min(z)])
            work_job,work_M,work_T,work_tran,work_wc=R1_job,R1_m,R1_t,R1_tr,R1_wc
            answer=answer11.copy()


            for i in range(0, self.popsize, 2):
                # print(work_job)
                # print(work_job[i:i + 1])
                job, machine, machine_time, trantime,wc= np.copy(work_job[i:i + 1]), np.copy(work_M[i:i + 1]), np.copy(
                    work_T[i:i + 1]), np.copy(work_tran[i:i + 1]),np.copy(work_wc[i:i+1])
                job1, machine1, machine_time1, trantime1,wc1 = np.copy(work_job[i + 1:i + 2]), np.copy(
                    work_M[i + 1:i + 2]), np.copy(work_T[i + 1:i + 2]), np.copy(work_tran[i + 1:i + 2]),np.copy(work_wc[i + 1:i + 2])
                OS_dic = self.to_MT(job, machine, machine_time, trantime,wc)
                OS_dic1 = self.to_MT(job1, machine1, machine_time1, trantime1,wc1)
                job_new, job_new1 = self.MOX(job, job1)
                machine_new, time_new, tran_new,wc_new = self.back_MT(job_new, OS_dic)
                # print(job_new)
                list_T, list_M, list_S, list_W, tmmw = self.to.caculate(job_new, machine_new, time_new, tran_new,wc_new)
                C_finish, Twork, E_all, _, _, _, _, _ = self.to.sig(list_T, list_M, list_S, list_W, job_new, tmmw,
                                                                    tran_new)
                if (C_finish<=answer[i][0] and Twork<=answer[i][1] and E_all<=answer[i][2]) and (C_finish<answer[i][0] or Twork<answer[i][1] or E_all<answer[i][2]):
                    work_job[i],work_M[i],work_T[i],work_tran[i],answer[i]=job_new,machine_new,time_new,tran_new,[C_finish,Twork,E_all]
                # work_job1[i] = job_new
                # work_M1[i] = machine_new
                # work_T1[i] = time_new
                # work_tran1[i] = tran_new
                # answer1.append([C_finish, Twork, E_all])
                machine_new1, time_new1, tran_new1,wc_new1 = self.back_MT(job_new1, OS_dic1)
                list_T, list_M, list_S, list_W, tmmw = self.to.caculate(job_new1, machine_new1, time_new1, tran_new1,wc_new1)
                C_finish, Twork, E_all, _, _, _, _, _ = self.to.sig(list_T, list_M, list_S, list_W, job_new1, tmmw,
                                                                    tran_new1)
                if (C_finish<=answer[i+1][0] and Twork<=answer[i+1][1] and E_all<=answer[i+1][2]) and (C_finish<answer[i+1][0] or Twork<answer[i+1][1] or E_all<answer[i+1][2]):
                    work_job[i],work_M[i],work_T[i],work_tran[i],answer[i]=job_new1,machine_new1,time_new1,tran_new1,[C_finish,Twork,E_all]
                # work_job1[i + 1] = job_new1
                # work_M1[i + 1] = machine_new1
                # work_T1[i + 1] = time_new1
                # work_tran1[i + 1] = tran_new1
                # answer1.append([C_finish, Twork, E_all])
            # print(R1_m)
            # print(answer11)
            front, crowd, crowder = self.oh.dis(answer)
            signal = front[0]
            pareto = np.array(answer11)[signal].tolist()
            pareto_tran, pareto_job, pareto_machine, pareto_time,pareto_wc = work_tran[signal], work_job[signal], work_M[signal], work_T[signal],work_wc[signal]
            x = [pareto[i][0] for i in range(len(pareto))]
            y = [pareto[i][1] for i in range(len(pareto))]
            z = [pareto[i][2] for i in range(len(pareto))]
            # print(x)
            # print(y)
            # print(z)
            fit_every[3].append(gen + 1)
            fit_every[0].append([min(x)])
            fit_every[1].append([min(y)])
            fit_every[2].append([min(z)])
            print('算法迭代到了第%.0f次' % (gen + 1))
        return pareto, pareto_job, pareto_machine, pareto_time, pareto_tran ,fit_every,pareto_wc # 返回pareto解及其编码

                # #LSO
                # for i in range(len(R1_job)):
                #     job,machine,machine_time,trantime=R1_job[i:i+1],R1_m[i:i+1],R1_t[i:i+1],R1_tr[i:i+1]
                #
                #     # print(job_new)
                #     # print(machine)
                #     # print(trantime)
                #     list_T, list_M, list_S, list_W, tmmw = self.to.caculate(job, machine, machine_time, trantime)
                #     C_finish, Twork, E_all,_,_,_,tmax ,list_T= self.to.plugin(list_T, list_M, list_S, list_W, job, tmmw,trantime)
                #     # print(list_M)
                #     # print(list_S)
                #     # print(list_W)
                #     # print(tmax)
                #     print(list_T)
                #     print(job)
                #     print(tmax)
                #
                #     # ind=[x for (x,y) in enumerate(list_M) if y==tmax]
                #     # print(ind)
                #
                #     # print(list_T[ma[0]])
                #     j, ma, time, tr, indxx = [], [], [], [], []
                #     # print(len(list_T[tmax])-1)
                #     c_job,c_ma,c_time,c_tr,ind=self.get_c(j,ma,time, tr, indxx,list_T,tmax,len(list_T[tmax])-1)#关键步骤的os、ma、加工时间、运输时间、和工序索引
                #     print(c_job)
                #     print(c_ma)
                #     print(c_time)
                #     print(c_tr)
                #     print(ind)
                #
                #     # exit()
                #     # for g in range(len(c_job)):
                #     #     if c_job[g]
                #     # for g in range(self.all_num):
                #
                #     p = random.random()
                #     if 1:#p<0.5:
                #         OS_dic = self.to_MT(job, machine, machine_time, trantime)
                #         P_1, P_2 = random.sample(range(0, len(c_job)), 2)
                #         print(P_1)
                #         print(P_2)
                #         print("ugig",job)
                #         ch=[]
                #         for h in [P_1,P_2]:
                #             inddd=0
                #             for g in range(self.all_num):
                #                 if job[0][g]==c_job[h] :
                #                     inddd += 1
                #                     if inddd==ind[h]:
                #                         ch.append(g)
                #                         print(11)
                #         # print(ch)
                #         job[0][ch[0]],job[0][ch[1]]=job[0][ch[1]],job[0][ch[0]]
                #         machine_new, time_new, tran_new = self.back_MT(job, OS_dic)
                #         list_T, list_M, list_S, list_W, tmmw = self.to.caculate(job, machine_new, time_new, tran_new)
                #         C_finish, Twork, E_all, _, _, _, _, _= self.to.plugin(list_T, list_M, list_S, list_W,job, tmmw, tran_new)
                #
                #         # print(job[0][ch[0]])
                #         # LSO_OS=0
                #     else:
                #         p1=random.random()
                #         if p<0.5:
                #             LSO_MPT=0
                #         else:
                #             LSO_RTT=0





        return 0


def compute():
    oj = data_deal()
    Tmachine,Tmachinetime,tdx,work,tom,int1,int2,M,M_dicr, tran_time, worker, work_num=oj.cacu()
    job_num=int2
    machine_num=M
    parm_data=[Tmachine,Tmachinetime,tdx,work,M_dicr, tran_time,int1,worker,work_num]
    to=FJSP(job_num,machine_num,parm_data,200)
    oh = mul_op()
    ho = ema(100,200, to, oh, work, job_num,tran_time,M_dicr,int1,Tmachine,Tmachinetime,parm_data[7])

    PFture=[]
    for i in range(10):
        pareto, pareto_job, pareto_machine, pareto_time, pareto_tran,fit_every,pareto_wc=ho.ema_total()
        PFture.extend(pareto)
        sig = 0
        job, machine = np.array([pareto_job[sig]]), np.array([pareto_machine[sig]])
        # print(pareto_machine)

        machine_time = np.array([pareto_time[sig]])
        trantime = np.array([pareto_tran[sig]])
        #to.draw(job, machine, machine_time, trantime)
        oh.draw_change(fit_every)
        print(pareto)
        print(fit_every)

    # pareto, pareto_job, pareto_machine, pareto_time, pareto_tran,fit_every=ho.ema_total()
    # print(pareto)
    # oh.draw_change(fit_every)
    front, crowd, crowder = mul_op().dis(PFture)
    sig = front[0]
    b = np.array(PFture)[sig].tolist()
    print(b)
    #b =[[342.0, 1158.0, 19129.646775200257], [359.0, 1159.0, 19122.837522772268]]
    be = b

    IGD=0
    ob1,ob2,ob3=[],[],[]
    for i in range(len(PFture)):
            ob1.append(PFture[i][0])
            ob2.append(PFture[i][1])
            ob3.append(PFture[i][2])
    for j in range(len(b)):
        ob1.append(b[j][0])
        ob2.append(b[j][1])
        ob3.append(b[j][2])
    max1,min1,max2,min2,max3,min3=max(ob1),min(ob1),max(ob2),min(ob2),max(ob3),min(ob3)
    maxob=[max1,max2,max3]
    minob=[min1,min2,min3]
    for i in range(len(PFture)):
            di=[]
            for j in range(len(b)):
                    diff=0
                    for ob in range(3):
                            if maxob[ob] == minob[ob]:
                                diff = 0
                            else:

                                fz1=(b[j][ob]-minob[ob])/(maxob[ob]-minob[ob])
                                # print(fz1)
                                fz2=(PFture[i][ob]-minob[ob])/(maxob[ob]-minob[ob])
                                # print(fz1,fz2)
                                diff=diff+pow(fz2-fz1,2)
                    di.append(diff)

            d=min(di)
            # print(d)
            IGD=IGD+math.sqrt(d)
            # print(IGD)\
    IGD = IGD/len(PFture)
    print("IGD=",IGD)
    #print(b)


        #print(F)
    b = np.array(PFture)[sig].tolist()
    PF = b

    ob1,ob2,ob3=[],[],[]
    for i in range(len(PFture)):
            ob1.append(PFture[i][0])
            ob2.append(PFture[i][1])
            ob3.append(PFture[i][2])
    for j in range(len(b)):
        ob1.append(b[j][0])
        ob2.append(b[j][1])
        ob3.append(b[j][2])
    max1,min1,max2,min2,max3,min3=max(ob1),min(ob1),max(ob2),min(ob2),max(ob3),min(ob3)
    maxob=[max1,max2,max3]
    minob=[min1,min2,min3]
    for i in range(len(PF)):
            for j in range(3):
                    if maxob[j] != minob[j]:
                        PF[i][j]=(PF[i][j]-minob[j])/(maxob[j]-minob[j])
                    else:
                        PF[i][j] = 0
                    # fz2=(PFture[i][0]-min1)/(max1-min1)
    #print(PF)
    # for i in range (len(PFture)):
    #     x.append(PFture[i][0])
    #     y.append(PFture[i][1])
    #     z.append(PFture[i][2])
    # x1=max(x)
    # y1=min(y)
    # z1=max(z)
    ref=[1.01,1.01,1.01]
    #print(ref)
    PF.sort(key=lambda ele: ele[0], reverse=True)  #按第一个元素降序排序
    ind=np.zeros(len(PF))

    a=[]
    for i in range(len(PF)):
        for j in range(len(PF)):
            if (PF[i][0]<=PF[j][0] and PF[i][1]<=PF[j][1] and PF[i][2]<=PF[j][2]) and (PF[i][0]<PF[j][0] or PF[i][1]<PF[j][1] or PF[i][2]<PF[j][2]):
                ind[j]+=1
    for i in range(len(ind)):
        if ind[i]==0:
            a.append(PF[i])
    #print(a)
    # print(type(a[0]))
    # a=[1.01,1.01,1.01]
    # b=a.copy()
    # HV=0
    # area=0
    # for i in range (len(a)):
    #     if i ==0:
    #         depth=ref[0]-a[i][0]
    #     else:
    #         depth=a[i-1][0]-a[i][0]
    #         b.remove(a[i-1])
    #     b.sort(key=lambda ele: ele[1], reverse=False)
    #     for j in range(len(b)):
    #         if j==0:
    #             depth1=abs(b[j][1]-ref[1])
    #         else:
    #             depth1 = abs(b[j][1] - b[j-1][1])
    #         area=area+depth1*abs(ref[2]-b[j][2])
    #     # print(area)
    #
    #     HV=HV+area*depth
    b = a.copy()
    b = np.array(b)
    hv_indicator = Hypervolume(ref_point=ref)
    hv = hv_indicator.do(b)

    print("hv=",hv)
    return IGD,hv,be
temp1,temp2 = 0,0
be = []
for i in range(10):
    igd,hv,b = compute()
    be.append(hv)
    temp1 = temp1 + igd
    temp2 = temp2 + hv
print("IGD=",temp1/10)
print("HV=",temp2/10)
print(be)