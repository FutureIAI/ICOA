# -*- coding: utf-8 -*-
# @Time    : 2022/4/13 20:23
# @Author  : ht
# @File    : small_work.py
# @Software: PyCharmjob
import json
import numpy as np
class data_deal:
    def __init__(self):
        self.name_list = ["job", "daoda_time", "jiezhi_time", "M", "job_num", "job_dicr", "int1", "int2",  "M_dicr", "tran_time","worker","work_num"]
        # "job":每个工件的工序在不同机器上处理的时间
        # "daoda_time"：到达时间
        # "jiezhi_time"：截止日期
        # "M"：机器数量
        # "job_num"：每个工件工序数量
        # "job_dicr"：每个工件对应的工序数字典
        # "int1"：总工序数
        # "int2"：总工件数
        # "M_dicr"：机器编号与所属车间,机器加工功率,空载功率的字典
        # "tran_time"：车间之间的运输时间
        # "worker":可参与机器
        # "work_num"：工人数量
        self.item = {}
        self.get_item()



    def precess_(self, data):
            if "[" in data and "," not in data:
                data = data.strip().replace("[ ", "[").replace(" ]", "]").replace("  ", ",").replace(" ", ",").replace("][", "], [")
            elif "{" in data:
                data = data.strip().replace("：", ":")
            return eval(data)


    def get_item(self):
        with open("data\small_data\D04.txt") as fp:
            datas = fp.readlines()
            for i in range(len(self.name_list)):
                data = self.precess_(datas[i])
                self.item[self.name_list[i]] = data
        return self.item

    def widthxx(self):
        widthx = []
        int2 = self.item["int2"]
        data = self.item['job']
        siga=0
        for i in range(int2):
            for j in range(len(data[i])):
                for k in range(10):
                    if data[i][j][k] > 0:
                        siga+=1
            widthx.append(siga)
            siga=0
        width = max(widthx)
        return width

    def tcaculate(self):
        int2=self.item["int2"]
        jobnum=self.item["job_num"]

        # width = self.widthxx()
        # Tmachine, Tmachinetime = np.zeros((int2, width)), np.zeros((int2, width))
        Tmachine = [ [ [] for j in range(jobnum[i])] for i in range(int2)]
        Tmachinetime = [ [ [] for j in range(jobnum[i])] for i in range(int2)]
        tdx,sdx,tom,toe=[],[],[],[]
        M=self.item['M']
        data=self.item['job']
        # for i in range(len(data)):
        #     for j in range(len(data[i])):
        #         for k in range(M):
        #             data[i][j][k]=40
        # print(data)
        q=0
        a=0
        for i in range(len(data)):
            for j in range(len(data[i])):
                for k in range(M):
                    if data[i][j][k] > 0:
                        Tmachine[i][j].append(k+1)
                        Tmachinetime[i][j].append(data[i][j][k])
                        q += 1
                        a += 1
                sdx.append(a)
                a=0
                toe.append(q)
            tdx.append(sdx)
            sdx=[]
            q = 0
            tom.append(toe)
            toe = []
        # Tmachine = Tmachine.tolist()
        # Tmachinetime=Tmachinetime.tolist()
        return Tmachine,Tmachinetime,tdx,tom


    def cacu(self):
        int2 = self.item["int2"]
        int1=self.item["int1"]
        M=self.item["M"]
        M_dicr = self.item["M_dicr"]
        tran_time = self.item["tran_time"]
        worker = self.item["worker"]
        work_num = self.item["work_num"]





        Tmachine, Tmachinetime, tdx ,tom= self.tcaculate()
        to, work = 0, []
        for i in range(int2):
            to += len(tdx[i])
            for j in range(1, len(tdx[i]) + 1, 1):
                work.append(i)
        # for i in range(int2):
        #     for j in range():
        #         if Tmachine[i][j]==1 or Tmachine[i][j]==2 or Tmachine[i][j]==3:
        #             tran.append(tran_num[0])
        #         if Tmachine[i][j] == 4 or Tmachine[i][j] == 5:
        #             tran.append(tran_num[1])
        #         if Tmachine[i][j] == 6 or Tmachine[i][j] == 7 or Tmachine[i][j]==8:
        #             tran.append(tran_num[2])
        #         if Tmachine[i][j] == 9 or Tmachine[i][j] == 10:
        #             tran.append(tran_num[3])
        #     Ttran.append(tran)
        #     tran=[]


        return Tmachine, Tmachinetime, tdx, work, tom, int1 , int2, M, M_dicr, tran_time,worker,work_num
# to=data_deal()
# Tmachine, Tmachinetime, tdx, work, tom, int1, int2, M, M_dicr, tran_time=to.cacu()
# print(Tmachine)
# print( Tmachinetime[17])
# print(Tmachine[17])
# print(tdx)
# print(work)
# print(tom)
# print(int1)
# print(int2)
# print(M)
# print(M_dicr)
# print(tran_time)

# # "M"：机器数量
# # "job_num"：每个工件工序数量
# # "job_dicr"：每个工件对应的工序数字典
# # "int1"：总工序数
# # "int2"：总工件数
# # "M_dicr"：机器编号与所属车间,机器加工功率,空载功率的字典
# # "tran_time"：车间之间的运输时间