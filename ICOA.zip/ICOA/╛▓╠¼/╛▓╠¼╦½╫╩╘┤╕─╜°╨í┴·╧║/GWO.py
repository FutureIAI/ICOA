from small_work import data_deal
from fjsp import FJSP
import numpy as np
import random
import copy
import math
# import matplotlib.pyplot as plt 
from scipy.stats import norm
from itertools import chain
import matplotlib.pyplot as plt
# from matplotlib.pylab import mpl
# mpl.rcParams['font.sans-serif'] = ['SimHei']  # 添加这条可以让图形显示中文
from scipy.stats import levy_stable
class gwo():
    def __init__(self,generation,popsize,to,oh,work,job_num,tran_time,M_dicr,Work_arr):
        self.generation = generation  # 迭代次数
        self.popsize = popsize  # 种群规模
        self.to = to
        self.oh = oh
        self.work = work
        self.job_num = job_num                  # 种群规模
        self.tran_time=tran_time
        self.M_dicr=M_dicr
        # print(self.job_num)
        self.Work_arr = Work_arr
    def to_MT(self,W1,M1,T1,WC): #把加工机器编码和加工时间编码转化为对应列表，目的是记录工件的加工时间和加工机器
        Ma_W1, Tm_W1, WCross, WC_W1=[],[],[],[]

        for i in range(self.job_num):#添加工件个数的空列表
            Ma_W1.append([]),Tm_W1.append([]),WCross.append([]),WC_W1.append([])

        for i in range(W1.shape[1]):
            signal1=int(W1[0,i])
            #
            # print("111",signal1)
            # print(Ma_W1[signal1])

            Ma_W1[signal1].append(M1[0,i]),Tm_W1[signal1].append(T1[0,i]),WC_W1[signal1].append(WC[0,i]); #记录每个工件【】的加工机器
            index=np.random.randint(0,2,1)[0]
            WCross[signal1].append(index)       #随机生成一个为0或者1的列表，用于后续的机器的均匀交叉
        return Ma_W1, Tm_W1, WCross, WC_W1         #工件的加工机器和加工时间 分为20个数列
    def back_MT(self,W1,Ma_W1,Tm_W1,WC1):  #列表返回机器及加工时间编码
        memory1=np.zeros((1,self.job_num),dtype=int)
        # print(W1)
        # print(Ma_W1)
        # print(Tr_W1)
        # print(len((Tr_W1)))
        m1,t1,wc=np.zeros((1,W1.shape[1])),np.zeros((1,W1.shape[1])),np.zeros((1,W1.shape[1]))
        for i in range(W1.shape[1]):
            signal1=int(W1[0,i])
            # print(signal1)
            # print(Tr_W1[signal1][memory1[0,signal1]])
            m1[0,i]=Ma_W1[signal1][memory1[0,signal1]] #读取对应工序的加工机器             一个工件的多个工序加工机器    得出机器和加工时间的序列
            t1[0,i]=Tm_W1[signal1][memory1[0,signal1]]
            wc[0][i]=WC1[signal1][memory1[0,signal1]]
            # r1[0,i]=Tr_W1[signal1][memory1[0,signal1]]
            memory1[0,signal1]+=1
            # print(memory1)
        return m1,t1,wc
    def mac_cross(self,Ma_W1,Tm_W1,Ma_W2,Tm_W2,WCross,WC_W1,WC_W2):  #机器均匀交叉

        MC1,MC2,TC1,TC2=[],[],[],[]
        TR1,TR2,trtime=[],[],[]
        WC1,WC2 = [],[]
        # print(WCross)
        # print(Ma_W1)
        # print(Ma_W2)
        for i in range(self.job_num):
            MC1.append([]),MC2.append([]),TC1.append([]),TC2.append([]),WC1.append([]),WC2.append([])
            c =len((WCross[i]))
            for j in range(c):
                if(WCross[i][j]==0):  #为0时继承另一个父代的加工机器选择
                    MC1[i].append(Ma_W1[i][j]), MC2[i].append(Ma_W2[i][j]), TC1[i].append(Tm_W1[i][j]), TC2[i].append(Tm_W2[i][j])#,WC1[i].append(float(self.select_different_number(self.Work_arr[int(Ma_W1[i][j])], WC_W1[i][j]))),WC2[i].append(float(self.select_different_number(self.Work_arr[int(Ma_W1[i][j])], WC_W2[i][j])))#, WC1[i].append(WC_W1[i][j]), WC2[i].append(WC_W2[i][j])
                else:                #为1时继承父代的机器选择
                    MC2[i].append(Ma_W1[i][j]), MC1[i].append(Ma_W2[i][j]), TC2[i].append(Tm_W1[i][j]), TC1[i].append(Tm_W2[i][j])#,WC2[i].append(float(self.select_different_number(self.Work_arr[int(Ma_W1[i][j])], WC_W1[i][j]))),WC1[i].append(float(self.select_different_number(self.Work_arr[int(Ma_W1[i][j])], WC_W2[i][j])))#, WC2[i].append(WC_W1[i][j]), WC1[i].append(WC_W2[i][j])
            for z in range(c):
                prob = random.random()
                if prob < 0.99:
                    if (WCross[i][z] == 0):
                        WC1[i].append(WC_W1[i][z]), WC2[i].append(WC_W2[i][z])
                    else:
                        WC2[i].append(WC_W1[i][z]), WC1[i].append(WC_W2[i][z])
                else:
                    if (WCross[i][z] == 0):
                        WC1[i].append(float(self.select_different_number(self.Work_arr[int(Ma_W1[i][z])], WC_W1[i][z])))
                        WC2[i].append(float(self.select_different_number(self.Work_arr[int(Ma_W1[i][z])], WC_W2[i][z])))
                    else:
                        WC2[i].append(float(self.select_different_number(self.Work_arr[int(Ma_W1[i][z])], WC_W1[i][z])))
                        WC1[i].append(float(self.select_different_number(self.Work_arr[int(Ma_W1[i][z])], WC_W2[i][z])))





        # else:
        #     MC1, MC2, TC1, TC2 = [], [], [], []
        #     TR1, TR2, trtime = [], [], []
        #     WC1, WC2 = [], []
        #     # print(WCross)
        #     # print(Ma_W1)
        #     # print(Ma_W2)
        #     for i in range(self.job_num):
        #         MC1.append([]), MC2.append([]), TC1.append([]), TC2.append([]), WC1.append([]), WC2.append([])
        #         c = len((WCross[i]))
        #         for j in range(c):
        #             if (WCross[i][j] == 0):  # 为0时继承另一个父代的加工机器选择
        #                 MC1[i].append(Ma_W1[i][j]), MC2[i].append(Ma_W2[i][j]), TC1[i].append(Tm_W1[i][j]), TC2[i].append(Tm_W2[i][j]), WC1[i].append(WC_W1[i][j]), WC2[i].append(WC_W2[i][j])
        #
        #             else:  # 为1时继承父代的机器选择
        #                 MC2[i].append(Ma_W1[i][j]), MC1[i].append(Ma_W2[i][j]), TC2[i].append(Tm_W1[i][j]), TC1[i].append( Tm_W2[i][j]), WC2[i].append(WC_W1[i][j]), WC1[i].append(WC_W2[i][j])






        # print(MC1)
        # print(MC2)
        # for i in range(len(MC1)):
        #     trtime = []
        #     for j in range(len(MC1[i])):
        #         if j==0 :
        #             trtime.append(0)
        #         elif j>0:
        #             x = list(self.M_dicr[int(MC1[i][j])])[0] - 1
        #             y = list(self.M_dicr[int(MC1[i][j-1])])[0] - 1
        #             trtime.append(self.tran_time[y][x])
        #     TR1.append(trtime)
        #     # print(trtime)
        #     # print(TR1)
        # trtime=[]
        # # print(MC2)
        # for i in range(len(MC2)):
        #     trtime = []
        #     for j in range(len(MC2[i])):
        #         if j == 0:
        #             trtime.append(0)
        #         elif j > 0:
        #             x = list(self.M_dicr[int(MC2[i][j])])[0] - 1
        #             y = list(self.M_dicr[int(MC2[i][j - 1])])[0] - 1
        #             trtime.append(self.tran_time[y][x])
        #     TR2.append(trtime)
        # print("MC1=",MC1)
        # # print("MC2=", MC2)
        # print("TC1=", TC1)
        # # print("TC2=", TC2)

        return MC1,TC1,MC2,TC2,WC1,WC2


    def select_different_number(self,list, number):
        while True:
            if len(list) == 1:
                return number
            else:
                random_number = np.random.choice(list)
                if random_number != number:
                    return random_number

    # def wc_cross(self,Wc1,Wc2,wc):
    #
    #
    #
    #     for i in range(len(self.work)):
    #         index = np.random.randint(0, 2, 1)[0]
    #         Cross.append(index)

    def gettran(self, job, machine):
        trantime = np.ones((1, job.shape[1]))
        index = []
        k = 0
        for i in range(self.job_num):

            for j in range(len(job[0])):
                if job[0][j] == i:
                    k += 1
                    index.append(j)
                    if k == 1:
                        trantime[0][j] = 0
                    else:
                        a = machine[0][j]  # 当前工序机器序号
                        b = machine[0][index[-2]]  # 该工件前一个工序机器编号
                        x = list(self.M_dicr[int(a)])[0] - 1
                        y = list(self.M_dicr[int(b)])[0] - 1
                        # print(x,y)

                        trantime[0][j] = self.tran_time[y][x]
            # 获取两个工序机器对应的车间

            index = []
            k = 0
        return trantime
    def POX_improve(self, Father_1, Father_2):
        """先选折一部分种群进行pox交叉操作，看看结果
        Father_1,Father_2父代的DNA序列
        """
        Father_1 = Father_1[0:len(self.work)].copy()
        #print(Father_1)
        Father_2 = Father_2[0:len(self.work)].copy()
        # Father_1 = Father_1.tolist()
        # print(Father_1)
        # Father_2 = Father_2.tolist()
        children_1 = np.zeros(len(self.work), dtype=int)
        children_2 = np.zeros(len(self.work), dtype=int)
        # 建立工件集合
        Job_set = [i_ for i_ in range(self.job_num)]  # 有10个工件
        J_set_1 = np.random.choice(Job_set, 2, replace=False)
        J_set_2 = np.random.choice(Job_set, 2, replace=False)
        index_J2_of_F1_set = []
        index_J1_of_F2_set = []
        for i in range(len(J_set_1)):
            index_J1_of_F1 = np.where(Father_1[0] == J_set_1[i])[0]
            #print(index_J1_of_F1)
            index_J1_of_F2 = np.where(Father_2[0] == J_set_1[i])[0]
            index_J2_of_F1 = np.where(Father_1[0] == J_set_2[i])[0]
            index_J2_of_F2 = np.where(Father_2[0] == J_set_2[i])[0]
            index_J2_of_F1_set.append(index_J2_of_F1)
            index_J1_of_F2_set.append(index_J1_of_F2)
            for i_1 in range(np.size(index_J1_of_F1)):
                a_1 = index_J1_of_F1[i_1]
                #print(a_1)
                # print(Father_1[a_1])
                children_1[a_1] = Father_1[0][a_1]
            for i_1 in range(np.size(index_J2_of_F2)):
                a_2 = index_J2_of_F2[i_1]
                # print(Father_1[a_1])
                children_2[a_2] = Father_2[0][a_2]
                # 第二部将F1的转接到C2
        # 将二维数组转化为一维数组
        index_delet_1 = list(chain.from_iterable(index_J2_of_F1_set))
        index_delet_2 = list(chain.from_iterable(index_J1_of_F2_set))
        Father_1_deleted = np.delete(Father_1[0], index_delet_1)
        Father_2_deleted = np.delete(Father_2[0], index_delet_2)
        index_0_insert_1 = np.where(children_2 == 0)[0]
        index_0_insert_2 = np.where(children_1 == 0)[0]
        for j in range(np.size(Father_1_deleted)):
            a_3 = index_0_insert_1[j]
            children_2[a_3] = Father_1_deleted[j]
        for j in range(np.size(Father_2_deleted)):
            a_4 = index_0_insert_2[j]
            children_1[a_4] = Father_2_deleted[j]
        return children_1, children_2

    def levy_flight(self,a):
        step = []
        for i in range(len(self.work)):
            sigma = np.power(np.math.gamma(1 + a) * np.sin(np.pi * a / 2) / np.math.gamma((1 + a) / 2) * a * np.power(2,(a - 1) / 2),1 / a)
            # sigma = np.array([sigma])
            # print(sigma)
            u = np.random.normal(0, sigma)
            v = np.random.normal(0, 1)
            step.append(u / np.power(np.abs(v), 1 / a))
        return step

    # 示例使用



    def gwo_total(self):
        # global to
        # oj=data_deal()#工序数量，机器数量
        # Tmachine,Tmachinetime,tdx,work,tom,int2, M, M_dicr, tran_time=oj.cacu()
        # parm_data=[Tmachine,Tmachinetime,tdx,work,M_dicr, tran_time]
        # # print(self.job_num,self.machine_num,self.pi,parm_data)
        # to=FJSP(self.job_num,s elf.machine_num,self.pi,parm_data)
        #
        # answer,result=[],[]
        # job_init=np.zeros((self.popsize,len(work)))
        answer = []
        fit_every = [[], [], [], []]
        job_init = np.zeros((self.popsize, len(self.work)))
        work_tran1, work_job1, work_M1, work_T1=np.zeros((self.popsize,len(self.work))),np.zeros((self.popsize,len(self.work))),np.zeros((self.popsize,len(self.work))),np.zeros((self.popsize,len(self.work)))
        work_tran, work_job, work_M ,work_T=np.zeros((self.popsize,len(self.work))),np.zeros((self.popsize,len(self.work))),np.zeros((self.popsize,len(self.work))),np.zeros((self.popsize,len(self.work)))
        work_tran2, work_job2, work_M2, work_T2 = np.zeros((self.popsize, len(self.work))), np.zeros((self.popsize, len(self.work))), np.zeros((self.popsize, len(self.work))), np.zeros((self.popsize, len(self.work)))
        work_wc ,work_wc1,work_wc2 = np.zeros((self.popsize,len(self.work))),np.zeros((self.popsize,len(self.work))),np.zeros((self.popsize,len(self.work)))
        # job_tran=np.zeros((self.popsize,len(self.work)))
        for gen in range(self.generation):#迭代次数100
            if(gen<1):
                work_job, work_M, work_T, work_tran, work_F , job_init , work_wc = self.to.creat_job()
                #第一次生成多个可行的工序编码，机器编码，时间编码
                for i in range(self.popsize):#种群规模100
                    # print(self.tran_time)
                    #Wc = np.array(WC[i])
                    # job,machine,machine_time,initial_a,self.trantime=self.to.creat_job()
                    _,_,list_T , list_M , list_S , list_W , tmmw , Wmax = self.to.caculate(work_job[i:i+1], work_M[i:i+1], work_T[i:i+1], work_tran[i:i+1],work_wc[i:i+1])
                    C_finish,Twork,E_all,_,_,_,_,_=self.to.plugin(list_T,list_M,list_S,list_W,work_job[i:i+1],tmmw, work_tran[i:i+1])
                    answer.append([C_finish,Twork,E_all])
                    # work_tran[i],work_job[i],work_M[i],work_T[i]=self.trantime[0],job[0],machine[0],machine_time[0]
                    # job_init[i]=initial_a
                for i in range(0,self.popsize,2):#机器均匀交叉
                    job, machine, machine_time , wc= work_job[i:i + 1], work_M[i:i + 1], work_T[i:i + 1],work_wc[i:i+1] #一条流程 第i个
                    Ma_W1, Tm_W1, WCross, WC_W1 = self.to_MT(job, machine, machine_time,wc)   #创建存储机器与加工时间的列表以及用于交叉的序列
                    job1, machine1, machine_time1,wc1= work_job[self.popsize-i-1: self.popsize-i], work_M[self.popsize-i-1: self.popsize-i], work_T[self.popsize-i-1: self.popsize-i],work_wc[self.popsize-i-1: self.popsize-i] #倒数第i个
                    Ma_W2, Tm_W2, WCross, WC_W2= self.to_MT(job1, machine1, machine_time1,wc1)

                    MC1, TC1, MC2, TC2 ,WC1, WC2= self.mac_cross(Ma_W1, Tm_W1, Ma_W2, Tm_W2, WCross,WC_W1,WC_W2)
                    # print(job)
                    # print(machine)
                    # print(trantime)
                    job_new1, job_new2 = self.POX_improve(job, job1)
                    job_new1, job_new2 = np.array(job_new1).reshape(1, len(self.work)), np.array(job_new2).reshape(1,
                                                                                                                   len(self.work))




                    machine_new, time_new, wc= self.back_MT(job_new1, MC1, TC1,WC1)
                    tran_new=self.gettran(job_new1,machine_new) #得到转运时间
                    _, _, list_T, list_M, list_S, list_W, tmmw,Wmax = self.to.caculate(job_new1, machine_new, time_new,tran_new,wc)
                    C_finish, Twork, E_all, _, _, _, _ ,_= self.to.plugin(list_T, list_M, list_S, list_W, job_new1, tmmw,tran_new)
                    answer2 = [C_finish, Twork, E_all]
                    #print('aaa')
                    #print(answer2)
                    # print(C_finish,Twork,E_all)
                    work_job1[i],work_tran1[i],work_M1[i],work_T1[i],work_wc1[i]=job_new1,tran_new,machine_new,time_new,wc#wc
                    answer.append(answer2)

                    machine_new1, time_new1, wc1 = self.back_MT(job_new2, MC2, TC2, WC2)
                    tran_new1 = self.gettran(job_new2, machine_new1)
                    _, _, list_T, list_M, list_S, list_W, tmmw,Wmax = self.to.caculate(job_new2, machine_new1, time_new1,tran_new1,wc1)
                    C_finish, Twork, E_all, _, _, _, _ ,_= self.to.plugin(list_T, list_M, list_S, list_W, job_new2, tmmw,tran_new1)
                    work_job1[i+1], work_tran1[i+1], work_M1[i+1], work_T1[i+1],work_wc1[i+1] = job_new2, tran_new1, machine_new1, time_new1,wc1#work_wc[i:i+1]
                    answer3 = [C_finish, Twork, E_all]
                    # print(answer3)

                    answer.append(answer3)
                    # print(C_finish)
                # print(answer)
                # print('种群初始的完工时间:%.0f'%(min(answer)))
                # result.append([gen,min(answer)])#记录初始解的最小完工时间
                # print(answer)#answer:一百个种群最晚完工时间表
                R_job, R_m, R_t, R_tr, R_wc = np.concatenate((work_job, work_job1)), np.concatenate((work_M, work_M1)), np.concatenate((work_T, work_T1)), np.concatenate((work_tran, work_tran1)), np.concatenate((work_wc,work_wc1))#work_job1为前后插入  1 n-1 2 n-2
                front, crowd, crowder = self.oh.dis(answer)  # 计算分层，拥挤度，种群排序结果
                # print(crowder)
                # print(front)
                # print(crowd)
                # print(crowder)
                # print(crowder)
                # print(answer[crowder[0]])
                # print(answer[crowder[1]])
                # exit()
                answer4=[]
                for i in range(self.popsize):
                    work_job1[i]=R_job[crowder[i]]
                    work_M1[i]=R_m[crowder[i]]
                    work_T1[i]=R_t[crowder[i]]
                    work_tran1[i]=R_tr[crowder[i]]
                    work_wc1[i]=R_wc[crowder[i]]
                    answer4.append(answer[crowder[i]])
                    # print(work_M[i])
                        #200个个体取前100个    100个个体   answer4 为加工后的种群
                # print(front)
                # print(crowder)
                front, crowd, crowder = self.oh.dis(answer4)
                # print(crowder)
                signal = front[0]  #当前层的结果 可能多个
                # print(signal)
                pareto = np.array(answer)[signal].tolist()
                pareto_job, pareto_machine, pareto_time = work_job1[signal], work_M1[signal], work_T1[signal]

                # _, _, list_T, list_M, list_S, list_W, tmmw, Wmax = self.to.caculate(pareto_job[0], pareto_machine[0], pareto_time[0], work_tran1[0], work_wc1[signal[0]])
                # C_finish, Twork, E_all, _, _, _, _, _ = self.to.plugin(list_T, list_M, list_S, list_W, pareto_job[0], tmmw, work_tran1[0])  #之前是tran_new1[0]


                x = [pareto[i][0] for i in range(len(pareto))]
                y = [pareto[i][1] for i in range(len(pareto))]
                z = [pareto[i][2] for i in range(len(pareto))]
                fit_every[3].append(gen)
                fit_every[0].append([min(x)])
                fit_every[1].append([min(y)])
                fit_every[2].append([min(z)])
            # exit()
                # print(fit_every)

            index_sort = crowder
            # print(index_sort)
            work_tran2, work_job2, work_M2, work_T2, work_wc2= work_tran1[index_sort],work_job1[index_sort], work_M1[index_sort], work_T1[index_sort], work_wc1[index_sort]
            if gen<1:
                answer2 = np.array(answer4)[index_sort].tolist()
            else:
                answer2 = np.array(answer4)[index_sort].tolist()
            job_init1 = job_init[index_sort]
            #从这开始写
            # print(job_init1)
            # exit()
            if gen <1 :
                xgx = answer2[int(crowder[0])]
                xg = job_init1[0]
                xg_job = work_job2[0]
                xg_mac = work_M2[0]
                xg_time = work_T2[0]


            else:
                for i in range(len(pareto)):
                    if (pareto[i][0] <= xgx[0] and pareto[i][1] <= xgx[1] and pareto[i][2] <= xgx[2]) and (
                            pareto[i][0] <= xgx[0] or pareto[i][1] <= xgx[1] or pareto[i][2] <= xgx[2]):
                        xg = job_init1[i]
                        xgx = pareto[i]
                        xg_job = pareto_job[i]
                        xg_mac = pareto_machine[i]
                        xg_time = pareto_time[i]




            xl = job_init1[0]
            temp = 20 + 15 * random.random()
            p = norm.pdf(temp, 25, 3)
            for i in range (1,self.popsize) :
                trantime, job, machine, machine_time,wc = work_tran2[i:i + 1], work_job2[i:i + 1], work_M2[i:i + 1], work_T2[i:i + 1], work_wc2[i:i+1]
                Ma_W1, Tm_W1, WCross, WC_W1 = self.to_MT(job, machine, machine_time,wc)
                x = job_init1[i]
                if temp >  30 :
                    x_shade = (xg+xl)/2
                    c2 = 2-(gen/self.generation)
                    a = random.random()
                    if a > 0.5:
                        p = random.random()
                        # if p > 0.3:
                        dis = x_shade - x
                        initial_a = x + c2 * random.random() * dis
                        # else:
                        #     steps = self.levy_flight(1.5)
                        #     initial_a = x + steps
                    else:
                        p = random.random()
                        # if p > 0.3:

                        initial_a = x - job_init1[random.randint(2, self.popsize - 1)] + x_shade
                        # else:
                        #     steps = self.levy_flight(1.5)
                        #     initial_a = x + steps
                else:
                    xfood = xg
                    c3 = 3
                    crit = (answer2[i][0] / xgx[0] + answer2[i][1] / xgx[1] + answer2[i][2] / xgx[2]) / 3
                    q = c3 * random.random() * crit
                    if q > (c3 + 1) / 2:
                        #p = random.random()
                        # if p > 0.3:

                        xfood = math.exp(-1 / q) * xfood
                        initial_a = x + xfood * p * (
                                np.cos(2 * np.pi * random.random()) - np.sin(2 * np.pi * random.random()))
                        # else:
                        #     steps = self.levy_flight(1.5)
                        #     initial_a = x + steps
                    else:
                        p = random.random()
                        # if p > 0.3:
                        initial_a = (x - xfood) * p + p * random.random() * x
                        # else:
                        #     steps = self.levy_flight(1.5)
                        #     initial_a = x + steps












            #
            # Alpha=job_init1[0]   #α狼
            # Beta=job_init1[1]    #β狼
            # Delta=job_init1[2]   #δ狼
            # a = 2*(1-gen/self.generation)
            #
            # for i in range(3,self.popsize):     #用最优位置进行工序编码的更新
            #     trantime, job, machine, machine_time,wc = work_tran2[i:i + 1], work_job2[i:i + 1], work_M2[i:i + 1], work_T2[i:i + 1], work_wc2[i:i+1]
            #     Ma_W1, Tm_W1, WCross, WC_W1 = self.to_MT(job, machine, machine_time,wc)
            #     x=job_init1[i]
            #
            #     r1 = random.random()   #灰狼算法解的更新
            #     r2 = random.random()
            #     A1 = 2 * a * r1 - a
            #     C1 = 2 * r2
            #     D_alpha =C1*Alpha-x
            #     x1 = x - A1 * D_alpha
            #
            #     r1 = random.random()
            #     r2 = random.random()
            #     A2 = 2 * a * r1 - a
            #     C2 = 2 * r2
            #     D_beta =C2*Beta-x
            #     x2 = x - A2 * D_beta
            #
            #     r1 = random.random()
            #     r2 = random.random()
            #     A3 = 2 * a * r1 - a
            #     C3 = 2 * r2
            #     D_delta =C3*Delta-x
            #     x3 = x - A3 * D_alpha
            #
            #     initial_a=(x1+x2+x3)/3   #更新公式
            #

                index_work=initial_a.argsort()
                job_new=[]
                for j in range(len(self.work)):
                    job_new.append(self.work[index_work[j]])


                job_new=np.array(job_new).reshape(1,len(self.work))
                # print(job_new)

                # print(job_new[0])
                # print("-----------------")
                machine_new,time_new,wc=self.back_MT(job_new,Ma_W1,Tm_W1,WC_W1)               # to MT 求加工时间和加工机器的数组  back to MT 通过上边的数组得出加工序列对应的机器和时间   caculate 计算序列 plugin插入工件并计算适应度
                tran_new = self.gettran(job_new, machine_new)

                # WC_new = np.zeros((1, len(self.work)))                                          #这里这里这里**********************
                # for k in range(len(self.work)):
                #     WC_new[0][k] = np.random.choice(self.Work_arr[int(machine_new[0][k])])


                # Wc  = np.array(WC[i])


                C_finish,_,list_T, list_M, list_S, list_W, tmmw,Wmax = self.to.caculate(job_new, machine_new, time_new, tran_new,wc)
                C_finish, Twork, E_all, _, _, _, _ ,_= self.to.plugin(list_T, list_M, list_S, list_W, job_new, tmmw, tran_new)
                # print(job_new[0])
                # C_finish,Twork,E_all,_,_,_,_=self.to.caculate(job_new,machine_new,time_new,self.trantime)
                # print(C_finish)
                # print(job_new)
                # print("hfdbgksb",machine_new)
                work_tran2[i]=tran_new[0]
                work_job2[i]=job_new[0]  #更新工序编码
                # print(work_job)
                # print(i)
                job_init1[i]=initial_a
                work_M2[i],work_T2[i]=machine_new[0],time_new[0]
                work_wc2[i] = wc[0]
                answer2[i]=[C_finish,Twork,E_all]
                # print(len(answer1))
                # print(len(work_job1))
                # exit()
            for i in range(0, self.popsize, 2):  # 机器均匀交叉
                job, machine, machine_time, wc = work_job2[i:i + 1], work_M2[i:i + 1], work_T2[i:i + 1],work_wc2[i:i+1]
                Ma_W1, Tm_W1, WCross, WC_W1 = self.to_MT(job, machine, machine_time,wc)
                job1, machine1, machine_time1, wc1= work_job2[i+1: i+2], work_M2[i+1: i+2], work_T2[i+1: i+2],work_wc2[i+1:i+2]
                Ma_W2, Tm_W2, WCross,WC_W2= self.to_MT(job1, machine1, machine_time1,wc1)

                MC1, TC1, MC2, TC2, WC1,WC2= self.mac_cross(Ma_W1, Tm_W1, Ma_W2, Tm_W2, WCross, WC_W1, WC_W2)
                    # print(job)
                    # print(machine)
                    # print(trantime)
                job_new1, job_new2 = self.POX_improve(job, job1)
                job_new1, job_new2 = np.array(job_new1).reshape(1, len(self.work)), np.array(job_new2).reshape(1,
                                                                                                               len(self.work))

                machine_new, time_new, wc = self.back_MT(job_new1, MC1, TC1,WC1)
                tran_new = self.gettran(job_new1, machine_new)


                _, _, list_T, list_M, list_S, list_W, tmmw,Wmax = self.to.caculate(job_new1, machine_new, time_new, tran_new,wc)
                C_finish, Twork, E_all, _, _, _, _, _ = self.to.plugin(list_T, list_M, list_S, list_W, job_new1, tmmw,tran_new)
                if (C_finish <= answer2[i][0] and Twork <= answer2[i][1] and E_all <= answer2[i][2]) and (C_finish < answer2[i][0] or Twork < answer2[i][1] or E_all < answer2[i][2]):
                    work_job2[i], work_M2[i], work_T2[i], work_tran2[i], work_wc2[i] , answer2[i] = job_new1, machine_new, time_new, tran_new,wc , [C_finish, Twork, E_all]

                    # answer2 = [C_finish, Twork, E_all]
                    # print(answer2)
                    # print(C_finish,Twork,E_all)
                    # work_job1[i], work_tran1[i], work_M1[i], work_T1[i], = job, tran_new, machine_new, time_new

                    # answer.append(answer2)
                machine_new1, time_new1, wc1 = self.back_MT(job_new2, MC2, TC2,WC2)
                tran_new1 = self.gettran(job_new2, machine_new1)
                _, _, list_T, list_M, list_S, list_W, tmmw , Wmax = self.to.caculate(job_new2, machine_new1, time_new1, tran_new1,wc1)
                C_finish, Twork, E_all, _, _, _, _, _ = self.to.plugin(list_T, list_M, list_S, list_W, job_new2, tmmw,tran_new1)
                work_job1[i + 1], work_tran1[i + 1], work_M1[i + 1], work_T1[i + 1], = job_new2, tran_new1, machine_new1, time_new1
                if (C_finish <= answer2[i+1][0] and Twork <= answer2[i+1][1] and E_all <= answer2[i+1][2]) and (C_finish < answer2[i+1][0] or Twork < answer2[i+1][1] or E_all < answer2[i+1][2]):
                    work_job2[i+1], work_M2[i+1], work_T2[i+1], work_tran2[i+1],work_wc2[i+1] , answer2[i+1] = job_new2, machine_new1, time_new1, tran_new1,wc1 , [C_finish, Twork, E_all]
                    # answer3 = [C_finish, Twork, E_all]
                    # print(answer3)

                # answer.append(answer3)

            # work_tran,work_job,work_M,work_T=work_tran1,work_job1,work_M1,work_T1
            # answer=answer1
            work_tran1, work_job1, work_M1, work_T1, work_wc1 = np.copy(work_tran2), np.copy(work_job2), np.copy(work_M2), np.copy(work_T2), np.copy(work_wc2)
            answer4 = answer2
            job_init = job_init1
            # job_init=job_init1
            front, crowd, crowder = self.oh.dis(answer4)
            signal = front[0]##先注释看下
            pareto = np.array(answer4)[signal].tolist()
            #pareto.sort(key=lambda x: x[0])
            pareto_tran,pareto_job, pareto_machine, pareto_time = work_tran1[signal],work_job1[signal], work_M1[signal], work_T1[signal]
            pareto_Wc = work_wc1[signal]
            # print(pareto)
            # print(answer)
            x = [pareto[i][0] for i in range(len(pareto))]
            y = [pareto[i][1] for i in range(len(pareto))]
            z = [pareto[i][2] for i in range(len(pareto))]
            # print(pareto)
            # print(x)
            # print(y)
            # print(z)
            fit_every[3].append(gen + 1)
            fit_every[0].append([min(x)])
            fit_every[1].append([min(y)])
            fit_every[2].append([min(z)])
            print(fit_every)
            # first_elements = [lst[0] for lst in pareto]
            # min_index = first_elements.index(min(first_elements))

            print('算法迭代到了第%.0f次' % (gen + 1))
            #print(pareto_job)
            print(pareto)
            # if gen == 99:
            #     PFture = answer4
            #
            #     b = pareto
            #
            #     IGD = 0
            #     ob1, ob2, ob3 = [], [], []
            #     for i in range(len(PFture)):
            #         ob1.append(PFture[i][0])
            #         ob2.append(PFture[i][1])
            #         ob3.append(PFture[i][2])
            #     max1, min1, max2, min2, max3, min3 = max(ob1), min(ob1), max(ob2), min(ob2), max(ob3), min(ob3)
            #     maxob = [max1, max2, max3]
            #     minob = [min1, min2, min3]
            #     for i in range(len(PFture)):
            #         di = []
            #         for j in range(len(b)):
            #             diff = 0
            #             for ob in range(3):
            #                 fz1 = (b[j][ob] - minob[ob]) / (maxob[ob] - minob[ob])
            #                 # print(fz1)
            #                 fz2 = (PFture[i][ob] - minob[ob]) / (maxob[ob] - minob[ob])
            #                 # print(fz1,fz2)
            #                 diff = diff + pow(fz2 - fz1, 2)
            #             di.append(diff)
            #
            #         d = min(di)
            #         # print(d)
            #         IGD = IGD + math.sqrt(d)
            #         # print(IGD)
            #     IGD = IGD / len(PFture)
            #     print("IGD=", IGD)
            #     # print(F)
            #     PF = b
            #
            #     ob1, ob2, ob3 = [], [], []
            #     for i in range(len(PFture)):
            #         ob1.append(PFture[i][0])
            #         ob2.append(PFture[i][1])
            #         ob3.append(PFture[i][2])
            #     max1, min1, max2, min2, max3, min3 = max(ob1), min(ob1), max(ob2), min(ob2), max(ob3), min(ob3)
            #     maxob = [max1, max2, max3]
            #     minob = [min1, min2, min3]
            #     for i in range(len(PF)):
            #         for j in range(3):
            #             PF[i][j] = (PF[i][j] - minob[j]) / (maxob[j] - minob[j])
            #             # fz2=(PFture[i][0]-min1)/(max1-min1)
            #     print(PF)
            #     # for i in range (len(PFture)):
            #     #     x.append(PFture[i][0])
            #     #     y.append(PFture[i][1])
            #     #     z.append(PFture[i][2])
            #     # x1=max(x)
            #     # y1=min(y)
            #     # z1=max(z)
            #     ref = [1.01, 1.01, 1.01]
            #     print(ref)
            #     PF.sort(key=lambda ele: ele[0], reverse=True)  # 按第一个元素降序排序
            #     ind = np.zeros(len(PF))
            #
            #     a = []
            #     for i in range(len(PF)):
            #         for j in range(len(PF)):
            #             if (PF[i][0] <= PF[j][0] and PF[i][1] <= PF[j][1] and PF[i][2] <= PF[j][2]) and (
            #                     PF[i][0] < PF[j][0] or PF[i][1] < PF[j][1] or PF[i][2] < PF[j][2]):
            #                 ind[j] += 1
            #     for i in range(len(ind)):
            #         if ind[i] == 0:
            #             a.append(PF[i])
            #     print(a)
            #     # print(type(a[0]))
            #     # a=[1.01,1.01,1.01]
            #     b = a.copy()
            #     HV = 0
            #     area = 0
            #     for i in range(len(a)):
            #         if i == 0:
            #             depth = ref[0] - a[i][0]
            #         else:
            #             depth = a[i - 1][0] - a[i][0]
            #             b.remove(a[i - 1])
            #         b.sort(key=lambda ele: ele[1], reverse=False)
            #         for j in range(len(b)):
            #             if j == 0:
            #                 depth1 = abs(b[j][1] - ref[1])
            #             else:
            #                 depth1 = abs(b[j][1] - b[j - 1][1])
            #             area = area + depth1 * abs(ref[2] - b[j][2])
            #         # print(area)
            #
            #         HV = HV + area * depth
            #
            #     print("hv=", HV)
       #print("AAAA")
        IGD,HV = 0,0
        return pareto,pareto_job,pareto_machine,pareto_time,pareto_tran,fit_every,pareto_Wc,IGD,HV  #返回pareto解及其编码
# m=data_deal()
# item_ = m.item
# job_num=item_["int2"]
# machine_num=item_["M"]
# ho=gwo([job_num,machine_num,0.5],100,100)    #第一个中括号是工件数，机器数，选择最短机器的概率
# #数50,100分别代表迭代的次数和种群的规模



# a,b,c,result,trantime=ho.gwo_total()  #最后一次迭代的最优解

# job,machine,machine_time=np.array([a]),np.array([b]),np.array([c])
# to.draw(job,machine,machine_time,trantime) #画图

# result=np.array(result).reshape(len(result),2)
# plt.plot(result[:,0],result[:,1])                   #画完工时间随迭代次数的变化
# font1={'weight':'bold','size':22}#汉字字体大小，可以修改
# plt.xlabel("迭代次数",font1)
# plt.title("完工时间变化图",font1)
# plt.ylabel("完工时间",font1)
# plt.savefig('zx.png')
# plt.show()