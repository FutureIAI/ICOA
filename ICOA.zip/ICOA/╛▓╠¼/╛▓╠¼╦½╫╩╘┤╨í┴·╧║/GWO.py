from small_work import data_deal
from fjsp import FJSP
import numpy as np
import random
import math
# import matplotlib.pyplot as plt 
from scipy.stats import norm
import matplotlib.pyplot as plt
# from matplotlib.pylab import mpl
# mpl.rcParams['font.sans-serif'] = ['SimHei']  # 添加这条可以让图形显示中文

class gwo():
    def __init__(self,generation,popsize,to,oh,work,job_num,tran_time,M_dicr):
        self.generation = generation  # 迭代次数
        self.popsize = popsize  # 种群规模
        self.to = to
        self.oh = oh
        self.work = work
        self.job_num = job_num                  # 种群规模
        self.tran_time=tran_time
        self.M_dicr=M_dicr
        # print(self.job_num)
    def to_MT(self,W1,M1,T1,R1,WC): #把加工机器编码和加工时间编码转化为对应列表，目的是记录工件的加工时间和加工机器
        Ma_W1,Tm_W1,WCross,Tr_W1=[],[],[],[]
        WC_W1 = []

        for i in range(self.job_num):#添加工件个数的空列表
            Ma_W1.append([]),Tm_W1.append([]),WCross.append([]),Tr_W1.append([]), WC_W1.append([])

        for i in range(W1.shape[1]):
            signal1=int(W1[0,i])
            #
            # print("111",signal1)
            # print(Ma_W1[signal1])

            Ma_W1[signal1].append(M1[0,i]),Tm_W1[signal1].append(T1[0,i]),Tr_W1[signal1].append(R1[0,i]), WC_W1[signal1].append(WC[0,i]); #记录每个工件的加工机器
            index=np.random.randint(0,2,1)[0]
            WCross[signal1].append(index)       #随机生成一个为0或者1的列表，用于后续的机器的均匀交叉
        return Ma_W1,Tm_W1,WCross,Tr_W1,WC_W1
    def back_MT(self,W1,Ma_W1,Tm_W1,Tr_W1,WC1):  #列表返回机器及加工时间编码
        memory1=np.zeros((1,self.job_num),dtype=int)
        m1,t1,r1=np.zeros((1,W1.shape[1])),np.zeros((1,W1.shape[1])),np.zeros((1,W1.shape[1]))
        wc = np.zeros((1,W1.shape[1]))
        for i in range(W1.shape[1]):
            signal1=int(W1[0,i])
            m1[0,i]=Ma_W1[signal1][memory1[0,signal1]] #读取对应工序的加工机器
            t1[0,i]=Tm_W1[signal1][memory1[0,signal1]]
            r1[0,i]=Tr_W1[signal1][memory1[0,signal1]]
            wc[0,i] = WC1[signal1][memory1[0,signal1]]
            memory1[0,signal1]+=1

        return m1,t1,r1,wc
    def mac_cross(self,Ma_W1,Tm_W1,Ma_W2,Tm_W2,WCross,WC_W1,WC_W2):  #机器均匀交叉
        MC1,MC2,TC1,TC2=[],[],[],[]
        TR1,TR2,trtime=[],[],[]
        WC1 = [], WC2 = []
        for i in range(self.job_num):     
            MC1.append([]),MC2.append([]),TC1.append([]),TC2.append([]),WC1.append([]), WC2.append([])
            for j in range(len(WCross[i])):
                if(WCross[i][j]==0):  #为0时继承另一个父代的加工机器选择
                    MC1[i].append(Ma_W1[i][j]),MC2[i].append(Ma_W2[i][j]),TC1[i].append(Tm_W1[i][j]),TC2[i].append(Tm_W2[i][j]),WC1[i].append(WC_W1[i][j]),WC2[i].append(WC_W2[i][j]);
                else:                #为1时继承父代的机器选择
                    MC2[i].append(Ma_W1[i][j]),MC1[i].append(Ma_W2[i][j]),TC2[i].append(Tm_W1[i][j]),TC1[i].append(Tm_W2[i][j]),WC2[i].append(WC_W1[i][j]),WC1[i].append(WC_W2[i][j]);
        for i in range(len(MC1)):
            for j in range(len(MC1[i])):
                if j==0 :
                    trtime.append(0)
                elif j>0:
                    x = list(self.M_dicr[int(MC1[i][j])])[0] - 1
                    y = list(self.M_dicr[int(MC1[i][j-1])])[0] - 1
                    trtime.append(self.tran_time[y][x])
                TR1.append(trtime)
        trtime=[]
        for i in range(len(MC2)):
            for j in range(len(MC2[i])):
                if j == 0:
                    trtime.append(0)
                elif j > 0:
                    x = list(self.M_dicr[int(MC2[i][j])])[0] - 1
                    y = list(self.M_dicr[int(MC2[i][j - 1])])[0] - 1
                    trtime.append(self.tran_time[y][x])
                TR2.append(trtime)
        # print("MC1=",MC1)
        # # print("MC2=", MC2)
        # print("TC1=", TC1)
        # # print("TC2=", TC2)

        return MC1,TC1,TR1,MC2,TC2,TR2,WC1,WC2

    def gwo_total(self):
        # global to
        # oj=data_deal()#工序数量，机器数量
        # Tmachine,Tmachinetime,tdx,work,tom,int2, M, M_dicr, tran_time=oj.cacu()
        # parm_data=[Tmachine,Tmachinetime,tdx,work,M_dicr, tran_time]
        # # print(self.job_num,self.machine_num,self.pi,parm_data)
        # to=FJSP(self.job_num,s elf.machine_num,self.pi,parm_data)
        #
        # answer,result=[],[]
        # job_init=np.zeros((self.popsize,len(work)))
        answer = []
        PFture = []
        temp1 = 0
        temp2 = 0
        fit_every = [[], [], [], []]
        job_init = np.zeros((self.popsize, len(self.work)))
        work_WC = np.zeros((self.popsize,len(self.work)))
        work_WC1 = np.zeros((self.popsize, len(self.work)))
        work_tran1,work_job1,work_M1,work_T1=np.zeros((self.popsize,len(self.work))),np.zeros((self.popsize,len(self.work))),np.zeros((self.popsize,len(self.work))),np.zeros((self.popsize,len(self.work)))
        work_tran,work_job,work_M,work_T=np.zeros((self.popsize,len(self.work))),np.zeros((self.popsize,len(self.work))),np.zeros((self.popsize,len(self.work))),np.zeros((self.popsize,len(self.work)))
        # job_tran=np.zeros((self.popsize,len(self.work)))
        for gen in range(self.generation):#迭代次数100
            if(gen<1):  #第一次生成多个可行的工序编码，机器编码，时间编码
                for i in range(self.popsize):  # 种群规模100
                    job, machine, machine_time, initial_a, self.trantime, WC = self.to.creat_job()
                    # C_finish, Twork, E_all, list_M, list_S, list_W, tmax = self.caculate(job, machine, machine_time,trantime)
                    C_finish, Twork, E_all, _, _, _, _, _ = self.to.caculate(job, machine, machine_time, self.trantime,
                                                                             WC)
                    # C_finish,Twork,E_all,_,_,_,_=self.to.plugin(list_T,list_M,list_S,list_W,job,tmmw,self.trantime)
                    answer.append([C_finish, Twork, E_all])
                    work_tran[i], work_job[i], work_M[i], work_T[i], work_WC[i] = self.trantime[0], job[0], machine[0], \
                                                                                  machine_time[0], WC[0]
                    job_init[i] = initial_a
                # result.append([gen,min(answer)])#记录初始解的最小完工时间
                # print(answer)#answer:一百个种群最晚完工时间表
                front, crowd, crowder = self.oh.dis(answer)  # 计算分层，拥挤度，种群排序结果
                # print(front)
                # print(crowder)
                signal = front[0]
                pareto = np.array(answer)[signal].tolist()
                pareto_job, pareto_machine, pareto_time = work_job[signal], work_M[signal], work_T[signal]
                x = [pareto[i][0] for i in range(len(pareto))]
                y = [pareto[i][1] for i in range(len(pareto))]
                z = [pareto[i][2] for i in range(len(pareto))]
                fit_every[3].append(gen)
                fit_every[0].append([min(x)])
                fit_every[1].append([min(y)])
                fit_every[2].append([min(z)])

            index_sort = crowder
            work_tran1,work_job1, work_M1, work_T1,work_WC1 = work_tran[index_sort],work_job[index_sort], work_M[index_sort], work_T[index_sort],work_WC[index_sort]
            answer1 = np.array(answer)[index_sort].tolist()
            job_init1 = job_init[index_sort]
            #print('************')
            if gen <1 :
                xgx = answer1[0]
                xg = job_init1[0]

            else:
                if (pareto[0][0] <= xgx[0] and pareto[0][1] <= xgx[1] and pareto[0][2] <= xgx[2]) and ( pareto[0][0] <= xgx[0] or pareto[0][1] <= xgx[1] or pareto[0][2] <= xgx[2]):
                    xg = job_init1[0]
                    xgx = pareto[0]

            xl = job_init1[0]
            temp = 20 + 15 * random.random()
            p = norm.pdf(temp, 25, 3)
            for i in range (1,self.popsize) :
                trantime, job, machine, machine_time , WC = work_tran1[i:i + 1], work_job1[i:i + 1], work_M1[i:i + 1], work_T1[i:i + 1], work_WC1[i:i+1]
                Ma_W1, Tm_W1, WCross,Tr_W1,WC_W1 = self.to_MT(job, machine, machine_time,trantime, WC)
                x = job_init1[i]
                if temp >  30 :
                    x_shade = (xg+xl)/2
                    c2 = 2-(gen/self.generation)
                    a = random.random()
                    if a >0.5:
                        dis = x_shade - x
                        initial_a = x + c2 * random.random()* dis
                    else:
                        initial_a = x - job_init1[random.randint(2,self.popsize-1)] + x_shade
                else:
                    xfood = xg
                    c3 = 3
                    crit = (answer1[i][0]/xgx[0] + answer1[i][1]/xgx[1] + answer1[i][2]/xgx[2])/3
                    q = c3 *random.random()*crit
                    if q> (c3 +1)/2:
                        xfood = math.exp(-1/q) * xfood
                        initial_a = x + xfood * p * (np.cos(2*np.pi*random.random())-np.sin(2*np.pi*random.random()))
                    else:
                        initial_a = (x - xfood) * p + p * random.random()*x








            #
            #
            #
            #print(initial_a)
            # Alpha=job_init1[0]   #α狼
            # Beta=job_init1[1]    #β狼
            # Delta=job_init1[2]   #δ狼
            # a = 2*(1-gen/self.generation)
            # #print(Alpha)
            #
            # for i in range(3,self.popsize):     #用最优位置进行工序编码的更新
            #     trantime,job,machine,machine_time,WC=work_tran1[i:i+1],work_job1[i:i+1],work_M1[i:i+1],work_T1[i:i+1],work_WC1[i:i+1]
            #     #print(job)
            #     #print(';;')
            #     #print(machine)
            #
            #     Ma_W1,Tm_W1,WCross,Tr_W1,WC_W1=self.to_MT(job,machine,machine_time,trantime,WC)   #改这个
            #     x=job_init1[i]
            #
            #     r1 = random.random()   #灰狼算法解的更新
            #     r2 = random.random()
            #     A1 = 2 * a * r1 - a
            #     C1 = 2 * r2
            #     D_alpha =C1*Alpha-x
            #     x1 = x - A1 * D_alpha
            #
            #     r1 = random.random()
            #     r2 = random.random()
            #     A2 = 2 * a * r1 - a
            #     C2 = 2 * r2
            #     D_beta =C2*Beta-x
            #     x2 = x - A2 * D_beta
            #
            #     r1 = random.random()
            #     r2 = random.random()
            #     A3 = 2 * a * r1 - a
            #     C3 = 2 * r2
            #     D_delta =C3*Delta-x
            #     x3 = x - A3 * D_alpha
            #
            #     initial_a=(x1+x2+x3)/3   #更新公式
                #print(gen)
                #print(initial_a)
                index_work=initial_a.argsort()  #得到升序索引
                #print(index_work)
                #print('++++')
                #print('***')
                #print(self.work)
                job_new=[]
                for j in range(len(self.work)):
                    job_new.append(self.work[index_work[j]])
                #print(job_new)
                job_new=np.array(job_new).reshape(1,len(self.work))
                #print(job_new)

                # print(job_new[0])
                # print("-----------------")
                machine_new,time_new,tran_new, wc=self.back_MT(job_new,Ma_W1,Tm_W1,Tr_W1,WC_W1)
                C_finish, Twork, E_all,_,_,_,_,_= self.to.caculate(job_new,machine_new, time_new, tran_new,wc)
                # _,_,list_T, list_M, list_S, list_W, tmmw = self.to.caculate(job_new, machine_new, time_new, tran_new)
                #C_finish, Twork, E_all, _, _, _, _,_ = self.to.plugin(list_T, list_M, list_S, list_W, job_new, tmmw, tran_new)
                # print(job_new[0])
                # C_finish,Twork,E_all,_,_,_,_=self.to.caculate(job_new,machine_new,time_new,self.trantime)

                work_tran1[i]=tran_new[0]
                work_job1[i]=job_new[0]  #更新工序编码
                # print(work_job)
                # print(i)
                job_init1[i]=initial_a
                work_M1[i],work_T1[i]=machine_new[0],time_new[0]
                answer1[i]=[C_finish,Twork,E_all]
                work_WC1[i] = wc[0]
                # print('answer=',answer1)
                # print('更新前',work_M1)
            # for i in range(0,self.popsize,2):
            #     job,machine,machine_time,trantime=work_job1[i:i+1],work_M1[i:i+1],work_T1[i:i+1],work_tran1[i:i+1]
            #     Ma_W1,Tm_W1,WCross,Tr_W1=self.to_MT(job,machine,machine_time,trantime)
            #     job1,machine1,machine_time1,trantime1=work_job1[i+1:i+2],work_M1[i+1:i+2],work_T1[i+1:i+2],work_tran1[i:i+2]
            #     Ma_W2,Tm_W2,WCross,Tr_W2=self.to_MT(job1,machine1,machine_time1,trantime1)
            #
            #     MC1,TC1,TR1,MC2,TC2,TR2=self.mac_cross(Ma_W1,Tm_W1,Ma_W2,Tm_W2,WCross)
            #     machine_new,time_new,tran_new=self.back_MT(job,MC1,TC1,TR1)
            #     # print(machine_new)
            #     # print(time_new)
            #     # print(tran_new)
            #     # exit()
            #     _, _, list_T, list_M, list_S, list_W, tmmw = self.to.caculate(job, machine_new, time_new, tran_new)
            #     C_finish, Twork, E_all, _, _, _, _ = self.to.plugin(list_T, list_M, list_S, list_W, job, tmmw,tran_new)
            #     answer2=[C_finish,Twork,E_all]
            #     # print(C_finish,Twork,E_all)
            #
            #     machine_new1, time_new1, tran_new1 = self.back_MT(job1, MC2, TC2, TR2)
            #     _, _, list_T, list_M, list_S, list_W, tmmw = self.to.caculate(job1, machine_new1, time_new1, tran_new1)
            #     C_finish, Twork, E_all, _, _, _, _ = self.to.plugin(list_T, list_M, list_S, list_W, job1, tmmw,
            #                                                         tran_new1)
            #
            work_tran,work_job,work_M,work_T,work_WC=work_tran1,work_job1,work_M1,work_T1,work_WC1
            answer=answer1
            job_init=job_init1
            # print(work_tran)
            # result.append([gen+1,min(answer)])#记录每一次迭代的最优个体
            # print('灰狼算法第%.0f次迭代的完工时间:%.0f'%(gen+1,min(answer)))
            # best_index=answer.tolist().index(min(answer))
            front, crowd, crowder = self.oh.dis(answer)##先注释看下
            # print(front)
            signal = front[0]##先注释看下
            # print(work_tran[signal])
            # print(signal)
            # print(signal)
            pareto = np.array(answer)[signal].tolist()##先注释看下
            # print(pareto)
            # print(work_job[signal])
            pareto_tran,pareto_job, pareto_machine, pareto_time,pareto_WC = work_tran[signal],work_job[signal], work_M[signal], work_T[signal],work_WC1[signal]
            # print('看看对不对',pareto_tran)
            # print("---------")
            # print(work_job[signal])
            # exit()
            x = [pareto[i][0] for i in range(len(pareto))]
            y = [pareto[i][1] for i in range(len(pareto))]
            z = [pareto[i][2] for i in range(len(pareto))]
            fit_every[3].append(gen + 1)
            fit_every[0].append([min(x)])
            fit_every[1].append([y[0]])
            fit_every[2].append([min(z)])
            print('算法迭代到了第%.0f次' % (gen + 1))
            # print(pareto_job)
            #print(fit_every)
            print(pareto)
            #print(self.work)
        # PFture = []
        # PFture.extend(answer)
        # b = pareto
        #
        # IGD = 0
        # ob1, ob2, ob3 = [], [], []
        # for i in range(len(PFture)):
        #     ob1.append(PFture[i][0])
        #     ob2.append(PFture[i][1])
        #     ob3.append(PFture[i][2])
        # max1, min1, max2, min2, max3, min3 = max(ob1), min(ob1), max(ob2), min(ob2), max(ob3), min(ob3)
        # maxob = [max1, max2, max3]
        # minob = [min1, min2, min3]
        # for i in range(len(PFture)):
        #     di = []
        #     for j in range(len(b)):
        #         diff = 0
        #         for ob in range(3):
        #             fz1 = (b[j][ob] - minob[ob]) / (maxob[ob] - minob[ob])
        #             # print(fz1)
        #             fz2 = (PFture[i][ob] - minob[ob]) / (maxob[ob] - minob[ob])
        #             # print(fz1,fz2)
        #             diff = diff + pow(fz2 - fz1, 2)
        #         di.append(diff)
        #
        #     d = min(di)
        #     # print(d)
        #     IGD = IGD + math.sqrt(d)
        #     # print(IGD)
        # IGD = IGD / len(PFture)
        # temp1 = temp + IGD
        # #print(b)
        #
        # PF = b
        #
        # ob1, ob2, ob3 = [], [], []
        # for i in range(len(PFture)):
        #     ob1.append(PFture[i][0])
        #     ob2.append(PFture[i][1])
        #     ob3.append(PFture[i][2])
        # max1, min1, max2, min2, max3, min3 = max(ob1), min(ob1), max(ob2), min(ob2), max(ob3), min(ob3)
        # maxob = [max1, max2, max3]
        # minob = [min1, min2, min3]
        # for i in range(len(PF)):
        #     for j in range(3):
        #         PF[i][j] = (PF[i][j] - minob[j]) / (maxob[j] - minob[j])
        #         # fz2=(PFture[i][0]-min1)/(max1-min1)
        # print(PF)
        # # for i in range (len(PFture)):
        # #     x.append(PFture[i][0])
        # #     y.append(PFture[i][1])
        # #     z.append(PFture[i][2])
        # # x1=max(x)
        # # y1=min(y)
        # # z1=max(z)
        # ref = [1.01, 1.01, 1.01]
        # print(ref)
        # PF.sort(key=lambda ele: ele[0], reverse=True)  # 按第一个元素降序排序
        # ind = np.zeros(len(PF))
        #
        # a = []
        # for i in range(len(PF)):
        #     for j in range(len(PF)):
        #         if (PF[i][0] <= PF[j][0] and PF[i][1] <= PF[j][1] and PF[i][2] <= PF[j][2]) and (
        #                 PF[i][0] < PF[j][0] or PF[i][1] < PF[j][1] or PF[i][2] < PF[j][2]):
        #             ind[j] += 1
        # for i in range(len(ind)):
        #     if ind[i] == 0:
        #         a.append(PF[i])
        # print(a)
        # # print(type(a[0]))
        # # a=[1.01,1.01,1.01]
        # b = a.copy()
        # HV = 0
        # area = 0
        # for i in range(len(a)):
        #     if i == 0:
        #         depth = ref[0] - a[i][0]
        #     else:
        #         depth = a[i - 1][0] - a[i][0]
        #         b.remove(a[i - 1])
        #     b.sort(key=lambda ele: ele[1], reverse=False)
        #     for j in range(len(b)):
        #         if j == 0:
        #             depth1 = abs(b[j][1] - ref[1])
        #         else:
        #             depth1 = abs(b[j][1] - b[j - 1][1])
        #         area = area + depth1 * abs(ref[2] - b[j][2])
        #     # print(area)
        #
        #     HV = HV + area * depth
        # temp2 = temp2 +HV
        #
        # print("hv=", HV)



        return pareto,pareto_job,pareto_machine,pareto_time,pareto_tran,fit_every,pareto_WC #返回pareto解及其编码
# m=data_deal()
# item_ = m.item
# job_num=item_["int2"]
# machine_num=item_["M"]
# ho=gwo([job_num,machine_num,0.5],100,100)    #第一个中括号是工件数，机器数，选择最短机器的概率
# #数50,100分别代表迭代的次数和种群的规模



# a,b,c,result,trantime=ho.gwo_total()  #最后一次迭代的最优解

# job,machine,machine_time=np.array([a]),np.array([b]),np.array([c])
# to.draw(job,machine,machine_time,trantime) #画图

# result=np.array(result).reshape(len(result),2)
# plt.plot(result[:,0],result[:,1])                   #画完工时间随迭代次数的变化
# font1={'weight':'bold','size':22}#汉字字体大小，可以修改
# plt.xlabel("迭代次数",font1)
# plt.title("完工时间变化图",font1)
# plt.ylabel("完工时间",font1)
# plt.savefig('zx.png')
# plt.show()