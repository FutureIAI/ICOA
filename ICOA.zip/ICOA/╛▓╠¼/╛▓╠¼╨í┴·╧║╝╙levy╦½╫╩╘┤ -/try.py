import math

def distanse(x, y):
        return math.sqrt(sum([pow(a - b, 2) for a, b in zip(x, y)]))

def get_IGD(c, a):
        print([min([distanse(i, j) for j in a]) for i in c])
        return sum([min([distanse(i, j) for j in a]) for i in c])


c=[[229.0, 1455.0, 21075.048006363064], [272.0, 1354.0, 19906.044912466758], [257.0, 1366.0, 19777.69677816004], [270.0, 1317.0, 20302.26654118374], [259.0, 1346.0, 19658.54938335564], [223.0, 1404.0, 19740.35335804198], [249.0, 1355.0, 20893.687622239653], [288.0, 1348.0, 20053.89691358883], [246.0, 1411.0, 21997.172891594702], [272.0, 1499.0, 20789.56390520685], [248.0, 1429.0, 20971.2104776973], [284.0, 1409.0, 20096.509339808083], [241.0, 1512.0, 22597.157409656684], [346.0, 1415.0, 20950.9576976613], [314.0, 1372.0, 21011.930989903318], [306.0, 1454.0, 21254.35948856704], [288.0, 1414.0, 21797.88986031938], [282.0, 1461.0, 21943.348322004575], [284.0, 1484.0, 21827.162418019372], [286.0, 1459.0, 22147.149506111044], [308.0, 1315.0, 20768.240424974698], [249.0, 1514.0, 21928.80963633045], [259.0, 1475.0, 22714.335612621788], [262.0, 1418.0, 21631.981227509223], [236.0, 1449.0, 20913.913945827833], [321.0, 1383.0, 20552.637362117628], [269.0, 1386.0, 20880.081943089503], [370.0, 1301.0, 21623.566572480482], [265.0, 1453.0, 22378.27854855998], [273.0, 1476.0, 22064.401334598133], [340.0, 1402.0, 20258.797961072887], [290.0, 1361.0, 20377.22593272969], [335.0, 1343.0, 21676.95516401366], [361.0, 1327.0, 21946.61880894946], [288.0, 1474.0, 21781.208431345647], [285.0, 1474.0, 21994.968482595348], [260.0, 1437.0, 20901.063352287398], [341.0, 1427.0, 22699.344503943285], [346.0, 1432.0, 20909.391736047284], [400.0, 1468.0, 20649.056421225036], [335.0, 1365.0, 22440.003950379276], [255.0, 1493.0, 21840.672703637985], [310.0, 1395.0, 22456.565597255485], [345.0, 1370.0, 21311.34761192524], [309.0, 1428.0, 21777.636577178557], [247.0, 1533.0, 22678.69468025463], [388.0, 1388.0, 20620.529980664207], [284.0, 1382.0, 21018.442532498335], [268.0, 1456.0, 21903.104253328052]]

a=[]
b=[[247.0, 1533.0, 22678.69468025463], [388.0, 1388.0, 20620.529980664207], [284.0, 1382.0, 21018.442532498335], [268.0, 1456.0, 21903.104253328052]]
# print(distanse([0,0], [3,4]))
# [[202.0, 1159.0, 17021.168036178584], [201.0, 1241.0, 18050.353601625455]]
print(len(c))
# num=0
#
# IGD=0
# for i in range(len(c)):
#
#         c1=c[i][0]
#         c2=c[i][1]
#         c3=c[i][2]
#         IGD=IGD+min(math.sqrt(math.pow(c1-a[0],2)+math.pow(c2-a[1],2)+math.pow(c3-a[2],2)))
# IGD = get_IGD(c, a)/ len(c)
# print(IGD)
IGD = get_IGD(c, b)/len(c)
print(IGD)


import matplotlib.pyplot as plt
import numpy as np

# 示例数据点: (目标1值, 目标2值)
# 帕累托最优解 (非支配解)
pareto_optimal_solutions = np.array([
    [10, 1],  # P1
    [7, 2],   # P2
    [5, 4],   # P3
    [3, 7],   # P4
    [2, 10]   # P5
])

# 被支配的解
dominated_solutions = np.array([
    [8, 5],   # D1
    [6, 8],   # D2
    [9, 3],   # D3
    [4, 9],   # D4
    [7, 6],   # D5
    [11, 2],  # D6
    [5, 11]   # D7
])

# 绘图
plt.figure(figsize=(8, 6)) # 调整了画布大小

# 绘制帕累托最优解并连接成前沿线
plt.plot(pareto_optimal_solutions[:, 0], pareto_optimal_solutions[:, 1],
         'bo-', label='非支配解', markersize=7) # 'bo-' 蓝色圆点实线
# 标记帕累托点 (可选, 如果点不多可以加上)
# labels_pareto = [f'P{i+1}' for i in range(len(pareto_optimal_solutions))]
# for i, label in enumerate(labels_pareto):
#     plt.text(pareto_optimal_solutions[i, 0] + 0.2, pareto_optimal_solutions[i, 1] + 0.2, label, color='blue', fontsize=9)

# 绘制被支配的解
plt.plot(dominated_solutions[:, 0], dominated_solutions[:, 1],
         'rx', label='支配解', markersize=7) # 'rx' 红色叉

# --- 修改部分：取消坐标轴数值，仅标注 F(1) 和 F(2) ---
plt.xlabel('F(1)', fontsize=14, labelpad=10) # X轴标签 F(1)
plt.ylabel('F(2)', fontsize=14, labelpad=10) # Y轴标签 F(2)

# 移除刻度值
plt.xticks([])
plt.yticks([])
# --- 修改结束 ---

# 设置图表属性
plt.title('Pareto Front Example (Abstract Axes)', fontsize=16)
plt.legend(fontsize=10)
# plt.grid(True, linestyle='--', alpha=0.5) # 网格线可以保留也可以去掉，这里注释掉了

# 确保所有数据点都在视图内，可以手动设置范围或让matplotlib自动调整
# 为了保持与之前数据点的相对位置，我们仍然需要定义数据的范围，即使不显示刻度
min_x_data = min(np.min(pareto_optimal_solutions[:,0]), np.min(dominated_solutions[:,0]))
max_x_data = max(np.max(pareto_optimal_solutions[:,0]), np.max(dominated_solutions[:,0]))
min_y_data = min(np.min(pareto_optimal_solutions[:,1]), np.min(dominated_solutions[:,1]))
max_y_data = max(np.max(pareto_optimal_solutions[:,1]), np.max(dominated_solutions[:,1]))

# 添加一些边距，使得F(1) F(2)标签不会太靠近图像边缘
plt.xlim(min_x_data - 1, max_x_data + 1)
plt.ylim(min_y_data - 1, max_y_data + 1)

# 如果需要，可以添加箭头指示优化方向 (更抽象)
# 例如，在左下角附近画一个指向左下的箭头，但不标注具体数值
# ax = plt.gca()
# ax.annotate("", xy=(min_x_data, min_y_data), xytext=(min_x_data+2, min_y_data+2),
#             arrowprops=dict(arrowstyle="->", color="green", lw=2))
# plt.text(min_x_data + 2.2, min_y_data + 2.2, "Better", color="green", fontsize=10)


# 移除图的边框线（spines）中的顶部和右部，使图像更简洁
ax = plt.gca()
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
# 可以选择性地将底部和左部的线作为坐标轴的视觉表示
# ax.spines['bottom'].set_position('zero') # 如果想让x轴在y=0处
# ax.spines['left'].set_position('zero')   # 如果想让y轴在x=0处
# 但对于帕累托图，通常保持默认的框式或仅移除上/右边框

plt.tight_layout() # 调整布局，防止标签重叠
plt.show()