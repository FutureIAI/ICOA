from small_work import data_deal
from fjsp import FJSP
from multi_opt import mul_op
from GWO import gwo
import numpy as np
import  math
from pymoo.indicators.hv import Hypervolume
PFture = [
[3302.0, 197426.69396100077, 9884.0],
[3511.0, 196585.89634516454, 9622.0],
[3363.0, 196165.48784521664, 9675.0],
[3326.0, 197819.74843231222, 9855.0],
[3595.0, 199399.06173405907, 9596.0],
[3703.0, 200095.40319507956, 9570.0],
[3762.0, 201855.53795351958, 9539.0],
[3571.0, 196302.9579185935, 9648.0],
[3405.0, 196892.53028668734, 9659.0],
[3939.0, 204865.4963740977, 9517.0],[3902.0, 204275.4689357565, 9527.0],
[3767.0, 201367.3498803116, 9565.0],
[3350.0, 197892.2110720186, 9838.0]]
answer = PFture
front,crowd,crowder =mul_op().dis(answer)
sig = front[0]
b =[[3674.0, 198410.78749465817, 9585.0],
[3534.0, 196979.4556589598, 9609.0],
[3597.0, 199033.11626187369, 9576.0],
]
IGD = 0
ob1, ob2, ob3 = [], [], []
for i in range(len(PFture)):
    ob1.append(PFture[i][0])
    ob2.append(PFture[i][1])
    ob3.append(PFture[i][2])
for j in range(len(b)):
    ob1.append(b[j][0])
    ob2.append(b[j][1])
    ob3.append(b[j][2])

max1, min1, max2, min2, max3, min3 = max(ob1), min(ob1), max(ob2), min(ob2), max(ob3), min(ob3)
maxob = [max1, max2, max3]
minob = [min1, min2, min3]
for i in range(len(PFture)):
    di = []
    for j in range(len(b)):
        diff = 0
        for ob in range(3):
            fz1 = (b[j][ob] - minob[ob]) / (maxob[ob] - minob[ob])
            # print(fz1)
            fz2 = (PFture[i][ob] - minob[ob]) / (maxob[ob] - minob[ob])
            # print(fz1,fz2)
            diff = diff + pow(fz2 - fz1, 2)
        di.append(diff)

    d = min(di)
    # print(d)
    IGD = IGD + math.sqrt(d)
    # print(IGD)
IGD = IGD / len(PFture)
print(IGD)
PF = b

ob1, ob2, ob3 = [], [], []
for i in range(len(PFture)):
    ob1.append(PFture[i][0])
    ob2.append(PFture[i][1])
    ob3.append(PFture[i][2])
for j in range(len(b)):
    ob1.append(b[j][0])
    ob2.append(b[j][1])
    ob3.append(b[j][2])
max1, min1, max2, min2, max3, min3 = max(ob1), min(ob1), max(ob2), min(ob2), max(ob3), min(ob3)
maxob = [max1, max2, max3]
minob = [min1, min2, min3]
for i in range(len(PF)):
    for j in range(3):
        PF[i][j] = (PF[i][j] - minob[j]) / (maxob[j] - minob[j])
        # fz2=(PFture[i][0]-min1)/(max1-min1)
# print(PF)
# for i in range (len(PFture)):
#     x.append(PFture[i][0])
#     y.append(PFture[i][1])
#     z.append(PFture[i][2])
# x1=max(x)
# y1=min(y)
# z1=max(z)
ref = [1.01, 1.01, 1.01]
# print(ref)
PF.sort(key=lambda ele: ele[0], reverse=True)  # 按第一个元素降序排序
ind = np.zeros(len(PF))

a = []
for i in range(len(PF)):
    for j in range(len(PF)):
        if (PF[i][0] <= PF[j][0] and PF[i][1] <= PF[j][1] and PF[i][2] <= PF[j][2]) and (
                PF[i][0] < PF[j][0] or PF[i][1] < PF[j][1] or PF[i][2] < PF[j][2]):
            ind[j] += 1
for i in range(len(ind)):
    if ind[i] == 0:
        a.append(PF[i])
# print(a)
# print(type(a[0]))
# a=[1.01,1.01,1.01]
b = a.copy()
# HV=0
# area=0
# for i in range (len(a)):
#     if i ==0:
#         depth=ref[0]-a[i][0]
#     else:
#         depth=a[i-1][0]-a[i][0]
#         b.remove(a[i-1])
#     b.sort(key=lambda ele: ele[1], reverse=False)
#     for j in range(len(b)):
#         if j==0:
#             depth1=abs(b[j][1]-ref[1])
#         else:
#             depth1 = abs(b[j][1] - b[j-1][1])
#         area=area+depth1*abs(ref[2]-b[j][2])
#     # print(area)
#
#     HV=HV+area*depth
b = np.array(b)
hv_indicator = Hypervolume(ref_point=ref)
hv = hv_indicator.do(b)
print(hv)
