import numpy as np
import random
import scipy
import matplotlib.pyplot as plt
from scipy.stats import norm
class cra:
    def __init__(self):

        mu=25
        c1 = 1
        sigma =3
        p =c1 * norm(loc=mu, scale=sigma)
        temp=random*20+15



