from small_work import data_deal
from fjsp import FJSP
from multi_opt import mul_op
from GWO import gwo
import numpy as np
import  math
import matplotlib.pyplot as plt
from pymoo.indicators.hv import Hypervolume


def distanse(x, y):
    return math.sqrt(sum([pow(a - b, 2) for a, b in zip(x, y)]))


def get_IGD(c, a):
    # IGD=0
    # for i in range(len(c)):
    #     c1=
    # print(min([distanse(i, j) for j in a]) for i in c)
    return sum([min([distanse(i, j) for j in a]) for i in c]) #遍历所有距离 21 34
def tmain():
    oj = data_deal()
    item_ = oj.item
    job_num = item_["int2"]
    machine_num = item_["M"]

    # oj=data_deal(10,6)               #工件数，机器数
    Tmachine, Tmachinetime, tdx, work, tom, int1,int2, M, M_dicr, tran_time,worker,work_num = oj.cacu()
    parm_data = [Tmachine, Tmachinetime, tdx, work, M_dicr, tran_time,int1,worker,work_num]
    # to=FJSP(10,6,0.5,parm_data)      #工件数，机器数，选择最短机器的概率和mk01的数据
    to = FJSP(job_num, machine_num, parm_data,200)
    _, _, _, _, _,_,_= to.creat_job()
    oh = mul_op()
    ho = gwo(100,200,to, oh, work, job_num,tran_time,M_dicr,parm_data[7],parm_data[8])  # 数50,100,10分别代表迭代的次数、种群的规模、机器数
    # print(work)
    # to是柔性车间模块，oh是多目标模块

    pareto, pareto_job, pareto_machine, pareto_time, pareto_tran, fit_every, WC, break_machine,break_time,repair_time = ho.gwo_total()  # 最后一次迭代的最优解
    first_elements = [lst[0] for lst in pareto]
    min_index = first_elements.index(min(first_elements))
    sig = min_index
    # pareto.sort(key=lambda x: x[0])
    # ind = [pareto.index(item) for item in pareto]
    # job, machine = np.array([pareto_job[ind[0]]]), np.array([pareto_machine[ind[0]]])
    # # print(pareto_machine)
    #
    # machine_time = np.array([pareto_time[ind[0]]])
    # trantime = np.array([pareto_tran[ind[0]]])
    # wc = np.array([WC[ind[0]]]) ##################这里

    job, machine = np.array([pareto_job[sig]]), np.array([pareto_machine[sig]])
    # print(pareto_machine)

    machine_time = np.array([pareto_time[sig]])
    trantime = np.array([pareto_tran[sig]])
    wc = np.array([WC[sig]])  ##################这里


    C_finish, _, list_T, list_M, list_S, list_W, tmmw, Wmax,_ =to.caculate(job, machine, machine_time, trantime, wc)#np.array([WC[i]]))
    C_finish, Twork, E_all, _, _, _, _, _ = to.plugin(list_T, list_M, list_S, list_W, job, tmmw, trantime)
    # print(fit_every)
    Ma_W1, Tm_W1, WCross, WC_W1 =ho.to_MT(job, machine, machine_time, wc)
    #print(len(WC_W1))
    #print(WC_W1[1][1])


    #to.draw(job, machine, machine_time, trantime, wc, WC_W1,break_time,repair_time,break_machine)
    #print(C_finish)

    oh.draw_change(fit_every)
    #oh.draw_3d(pareto)
    # print(pareto)
    # print(' parato 解集内解的个数为',len(pareto))

    # print(job)
    #
    # print(machine)
    # print(machine_time)
    # print(trantime)
    #print("a")


    return pareto,oh,to,pareto_job, pareto_machine, pareto_time, pareto_tran, fit_every

PFture=[]
for i in range(10):
    paretoture,_,_,_,_,_,_,F=tmain()
    PFture.extend(paretoture)
    #print(A)
    print("AAA")
    print(paretoture)
    print(F)
    # for i in range(101):
    #     plt.plot(i,F[2][i],marker='o',linestyle='-', color='blue')
    #     if i == 0:
    #         plt.xlabel('轮')
    #         plt.ylabel('完成时间')
    #
    # plt.show()


    #print(F)
front, crowd, crowder = mul_op().dis(PFture)
sig = front[0]
b = np.array(PFture)[sig].tolist()


IGD=0
ob1,ob2,ob3,ob4=[],[],[],[]
for i in range(len(PFture)):
        ob1.append(PFture[i][0])
        ob2.append(PFture[i][1])
        ob3.append(PFture[i][2])
        ob4.append(PFture[i][3])
max1,min1,max2,min2,max3,min3,max4,min4=max(ob1),min(ob1),max(ob2),min(ob2),max(ob3),min(ob3),max(ob4),min(ob4)
maxob=[max1,max2,max3,max4]
minob=[min1,min2,min3,min4]
for i in range(len(PFture)):
        di=[]
        for j in range(len(b)):
                diff=0
                for ob in range(3):

                        fz1=(b[j][ob]-minob[ob])/(maxob[ob]-minob[ob])
                        # print(fz1)
                        fz2=(PFture[i][ob]-minob[ob])/(maxob[ob]-minob[ob])
                        # print(fz1,fz2)
                        diff=diff+pow(fz2-fz1,2)
                di.append(diff)

        d=min(di)
        # print(d)
        IGD=IGD+math.sqrt(d)
        # print(IGD)
print("IGD=",IGD/len(PFture))
print(b)


    #print(F)
PF = b

ob1,ob2,ob3,ob4=[],[],[],[]
for i in range(len(PFture)):
    ob1.append(PFture[i][0])
    ob2.append(PFture[i][1])
    ob3.append(PFture[i][2])
    ob4.append(PFture[i][3])
max1,min1,max2,min2,max3,min3,max4,min4=max(ob1),min(ob1),max(ob2),min(ob2),max(ob3),min(ob3),max(ob4),min(ob4)
maxob=[max1,max2,max3,max4]
minob=[min1,min2,min3,min4]
for i in range(len(PF)):
        for j in range(4):
                PF[i][j]=(PF[i][j]-minob[j])/(maxob[j]-minob[j])
                # fz2=(PFture[i][0]-min1)/(max1-min1)
print(PF)
# for i in range (len(PFture)):
#     x.append(PFture[i][0])
#     y.append(PFture[i][1])
#     z.append(PFture[i][2])
# x1=max(x)
# y1=min(y)
# z1=max(z)
ref=[1.01,1.01,1.01,1.01]
print(ref)
PF.sort(key=lambda ele: ele[0], reverse=True)  #按第一个元素降序排序
ind=np.zeros(len(PF))

a=[]
for i in range(len(PF)):
    for j in range(len(PF)):
        if (PF[i][0]<=PF[j][0] and PF[i][1]<=PF[j][1] and PF[i][2]<=PF[j][2] and PF[i][3]<=PF[j][3]) and (PF[i][0]<PF[j][0] or PF[i][1]<PF[j][1] or PF[i][2]<PF[j][2] or PF[i][3]<PF[j][3]):
            ind[j]+=1
for i in range(len(ind)):
    if ind[i]==0:
        a.append(PF[i])
print(a)
# print(type(a[0]))
# a=[1.01,1.01,1.01]
b = a.copy()
b = np.array(b)
hv_indicator = Hypervolume(ref_point=ref)
hv = hv_indicator.do(b)
# b=a.copy()
# HV=0
# area=0
# for i in range (len(a)):
#     if i ==0:
#         depth=ref[0]-a[i][0]
#     else:
#         depth=a[i-1][0]-a[i][0]
#         b.remove(a[i-1])
#     b.sort(key=lambda ele: ele[1], reverse=False)
#     for j in range(len(b)):
#         if j==0:
#             depth1=abs(b[j][1]-ref[1])
#         else:
#             depth1 = abs(b[j][1] - b[j-1][1])
#         area=area+depth1*abs(ref[2]-b[j][2])
#     # print(area)
#
#     HV=HV+area*depth

print("hv=",hv)

