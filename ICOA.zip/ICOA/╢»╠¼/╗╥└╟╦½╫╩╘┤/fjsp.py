import numpy as np
from small_work import data_deal
import random 
import matplotlib.pyplot as plt
from matplotlib.pylab import mpl
mpl.rcParams['font.sans-serif'] = ['SimHei']  # 添加这条可以让图形显示中文


class FJSP():
	def __init__(self,job_num,machine_num,pi,parm_data,popsize):
		self.job_num=job_num     			#工件数
		self.machine_num=machine_num		#机器数
		self.pi=pi  				#随机挑选机器的概率
		self.Tmachine,self.Tmachinetime,self.tdx,self.work,self.M_dicr, self.tran_time,self.all_num,self.work_arr,self.work_num=parm_data[0],parm_data[1],parm_data[2],parm_data[3],parm_data[4],parm_data[5],parm_data[6],parm_data[7],parm_data[8]
		self.popsize = popsize
	def axis(self):
		index=['M1','M2','M3','M4','M5','M6','M7','M8','M9','M10','M11','M12',
		'M13','M14','M15','M16','M17','M18','M19','M20']
		scale_ls,index_ls=[],[]   
		for i in range(self.machine_num):
			scale_ls.append(i+1)
			index_ls.append(index[i])
		return index_ls,scale_ls  #返回坐标轴信息，按照工件数返回，最多画20个机器，需要在后面添加
	def getind(self,list_T,job):
		ind = np.zeros((1, self.job_num))
		# print(job,len(job[0]))
		# print(self.job_num)
		# print(list_T)
		for i in range(len(job[0])):
			# print(i)
			if job[0][i] == list_T[0]:

				ind[0][list_T[0]]+=1
				# print(ind)
				# print("-----")

				if list_T[1]==ind[0][list_T[0]]:

					break
		return i
	def creat_job(self):

			initial_a = np.random.rand(len(self.work))  # 通过本函数可以返回一个或一组服从“0~1”均匀分布的随机样本值。随机样本取值范围是[0,1)，不包括1
			index_work=np.array(initial_a).argsort()  # 将随机样本值由小到大排列，排列出其对应的索引
			job = []
			# print(self.work)
			for i in range(len(self.work)):
				job.append(self.work[index_work[i]])
			job = np.array(job).reshape(1, len(self.work))   #1*N
			j,q=0,0
			machine=np.ones((1,job.shape[1]))
			machine_time = np.ones((1, job.shape[1]))

			job_s=[0]*(self.job_num)
			for i in job[0]:
				job_s[i]+=1
				j=job_s[i]
				#print(Tmachine[i][j])
				if np.random.rand()>self.pi:     			#选取最小加工时间机器
					machine_time[0,q]=min(self.Tmachinetime[i][j-1])
					for z in range(len(self.Tmachinetime[i][j - 1])):
						if self.Tmachinetime[i][j - 1][z] == machine_time[0][q]:
							machine[0][q] = self.Tmachine[i][j - 1][z]-1
				else:
					a=self.Tmachine[i][j-1]
					b=random.choice(a)
					machine[0][q] = b-1
					for z in range(len(self.Tmachine[i][j-1])):
						if self.Tmachine[i][j-1][z]==b:
							machine_time[0][q]=self.Tmachinetime[i][j-1][z]

				q+=1
			# print(job)
			# print(machine)
			# print(machine_time)
			trantime= np.ones((1, job.shape[1]))
			# print(trantime)
			index=[]
			k=0
            # print()
			for i in range(self.job_num):
				for j in range(len(job[0])):
					if job[0][j] == i:
						k+=1

						index.append(j)
					if job[0][j]==i and k==1:
						trantime[0][j]=0
					if job[0][j]==i and k>1:
						a=machine[0][j]#当前工序机器序号
						# print(index)
						b=machine[0][index[-2]]#该工件前一个工序机器编号
						# print(self.M_dicr)
						# print(self.M_dicr[int(a)])
						# print(self.M_dicr[int(b)])
						# print("******************"+str(i))
						x=list(self.M_dicr[int(a)])[0]-1
						y=list(self.M_dicr[int(b)])[0]-1
						# print(x,y)

						trantime[0][j]=self.tran_time[y][x]
						#获取两个工序机器对应的车间
				
				index=[]
				k=0

			# print(trantime)
			#job：工序编码
			#machine：机器编码
			# print(machine.astype(np.int))
			# print(len(machine[0]))




				# print(job_s)
			WC=[]
			for j in range(len(self.work)):
				WC.append(np.random.choice(self.work_arr[int(machine[0,j])]))
			WC = np.array(WC).reshape(1, len(self.work))


			

			return job,machine,machine_time,initial_a,trantime,WC

	def caculate(self, job, machine, machine_time, trantime, WC):
		# print(job)
		# print(p1,p2)
		jobtime = np.zeros((1, self.job_num))  # 工件对应的完成时间
		tmm = np.zeros((1, self.machine_num))  # 各个机器实际完成工件总时长
		work_time = np.zeros((1, self.work_num))  # 每个工人工作结束时间

		# print(tmm)
		# print(machine)
		tmmw = np.zeros((1, self.machine_num))  # 各个机器理论工作时间
		startime = 0  # 工序开始时间
		list_M, list_S, list_W, list_WO = [], [], [], []  # S:所有开始时间列表，W：完成时间列表,M:所用机器列表;
		list_T = [[] for range in tmm[0]]
		# svg:第i个工序所属的工件号  sig：第i个工序所对应的机器
		inde = np.zeros((1, self.job_num))
		for i in range(job.shape[1]):
			svg, sig, swg = int(job[0, i]), int(machine[0, i]), int(
				WC[0, i] - 1)  # svg 工序号，sig机器号 job为工序加工编码 machine为机器编码

			# print(sig)
			inde[0, int(job[0][i])] += 1  # 工件已完成的工序个数
			if (jobtime[0, svg] > 0):
				startime = max(jobtime[0, svg], tmm[0, sig], work_time[0, swg]) + trantime[0, i]
				tmm[0, sig] = startime + machine_time[0, i]
				jobtime[0, svg] = startime + machine_time[0, i]
				work_time[0, swg] = startime + machine_time[0, i]

			if (jobtime[0, svg] == 0):
				startime = max(tmm[0, sig], work_time[0, swg])
				tmm[0, sig] = startime + machine_time[0, i]
				jobtime[0, svg] = startime + machine_time[0, i]
				work_time[0, swg] = startime + machine_time[0, i]

			list_M.append(machine[0, i])
			list_S.append(startime)
			list_W.append(machine_time[0, i])
			list_T[sig].append(
				[svg, int(inde[0, int(job[0][i])]), int(startime), int(machine_time[0, i]), int(trantime[0, i]),
				 int(swg) + 1])  # list _T :工件号（同一工件的各个工序一样），已完成工序数（正在加工），开始时间，加工时间，转移时间
			tmmw[0, sig] += (machine_time[0, i] + trantime[0, i])
			list_WO.append(swg)

		tmax = np.argmax(tmm[0]) + 1  # 结束最晚的机器
		Wmax = np.argmax(work_time[0])
		C_finish = max(tmm[0])  # 最晚完工时间\
		T_work1 = sum(tmmw[0])
		# print(list_T)

		return C_finish, tmax, list_T, list_M, list_S, list_W, tmmw, Wmax, T_work1

	def recaculate(self, job, machine, machine_time, trantime, WC, ma, To, Tr):
		# print(job)
		# print(p1,p2)
		ma = ma - 1
		jobtime = np.zeros((1, self.job_num))  # 工件对应的完成时间
		tmm = np.zeros((1, self.machine_num))  # 各个机器实际完成工件总时长
		work_time = np.zeros((1, self.work_num))  # 每个工人工作结束时间

		# print(tmm)
		# print(machine)
		tmmw = np.zeros((1, self.machine_num))  # 各个机器理论工作时间
		startime = 0  # 工序开始时间
		list_M, list_S, list_W, list_WO = [], [], [], []  # S:所有开始时间列表，W：完成时间列表,M:所用机器列表;
		list_T = [[] for range in tmm[0]]
		# svg:第i个工序所属的工件号  sig：第i个工序所对应的机器
		inde = np.zeros((1, self.job_num))
		for i in range(job.shape[1]):
			svg, sig, swg = int(job[0, i]), int(machine[0, i]), int(
				WC[0, i] - 1)  # svg 工序号，sig机器号 job为工序加工编码 machine为机器编码

			# print(sig)
			inde[0, int(job[0][i])] += 1  # 工件已完成的工序个数

			if (jobtime[0, svg] > 0):
				startime = max(jobtime[0, svg], tmm[0, sig], work_time[0, swg]) + trantime[0, i]
				# if (sig == ma and startime >To and startime <To +Tr):
				# 	startime = max(startime,To+Tr)
				if (sig == ma and (startime + machine_time[0, i] >= To and startime + machine_time[
					0, i] <= To + Tr or startime >= To and startime <= To + Tr or startime <= To and startime +
								   machine_time[0, i] >= To + Tr)):
					startime = max(jobtime[0, svg], tmm[0, sig], work_time[0, swg], To + Tr) + trantime[0, i]
					tmm[0, sig] = startime + machine_time[0, i]

					jobtime[0, svg] = startime + machine_time[0, i]
					work_time[0, swg] = startime + machine_time[0, i]
				else:
					tmm[0, sig] = startime + machine_time[0, i]

					jobtime[0, svg] = startime + machine_time[0, i]
					work_time[0, swg] = startime + machine_time[0, i]

			if (jobtime[0, svg] == 0):

				startime = max(tmm[0, sig], work_time[0, swg])
				# if (sig == ma and startime >To and startime <To +Tr):
				# 	startime = max(startime,To+Tr)
				if (sig == ma and (startime + machine_time[0, i] >= To and startime + machine_time[
					0, i] <= To + Tr or startime >= To and startime <= To + Tr or startime <= To and startime +
								   machine_time[0, i] >= To + Tr)):
					startime = max(tmm[0, sig], work_time[0, swg], To + Tr) + trantime[0, i]
					tmm[0, sig] = startime + machine_time[0, i]

					jobtime[0, svg] = startime + machine_time[0, i]
					work_time[0, swg] = startime + machine_time[0, i]
				else:
					tmm[0, sig] = startime + machine_time[0, i]

					jobtime[0, svg] = startime + machine_time[0, i]
					work_time[0, swg] = startime + machine_time[0, i]

			list_M.append(machine[0, i])
			list_S.append(startime)
			list_W.append(machine_time[0, i])
			list_T[sig].append(
				[svg, int(inde[0, int(job[0][i])]), int(startime), int(machine_time[0, i]), int(trantime[0, i]),
				 int(swg) + 1])  # list _T :工件号（同一工件的各个工序一样），已完成工序数（正在加工），开始时间，加工时间，转移时间
			tmmw[0, sig] += (machine_time[0, i] + trantime[0, i])
			list_WO.append(swg)

		tmax = np.argmax(tmm[0]) + 1  # 结束最晚的机器
		Wmax = np.argmax(work_time[0])
		C_finish = max(tmm[0])  # 最晚完工时间
		# print(list_T)
		p1, p2 = [], []
		# print(type(job))
		job = job.tolist()
		# print(type(job))
		for i in range(self.machine_num):
			p1.append(self.M_dicr[i][1])
			p2.append(self.M_dicr[i][2])

		job = np.array(job)
		tmm = np.zeros((1, self.machine_num))
		ind = np.zeros((1, self.job_num))
		list_M, list_S, list_W, = [], [], []
		for i in range(job.shape[1]):
			x = int(job[0, i])
			ind[0, int(job[0][i])] += 1
			y = int(ind[0, int(job[0][i])])
			# print(type(y))
			# print(y)
			# print(x)
			for j in range(len(list_T)):
				for k in range(len(list_T[j])):
					if (list_T[j][k][0] == x) and (list_T[j][k][1] == y):
						list_S.append(list_T[j][k][2])
						list_M.append(j)
						list_W.append(list_T[j][k][3])
						tmm[0, j] = max(list_T[j][k][2] + list_T[j][k][3], tmm[0, j])

		trest = tmm - tmmw
		E_all = sum((tmmw * p1)[0]) + sum((trest * p2)[0 - 1]) + sum((trantime * 1.5)[0])  # 加工功率+空载功率+运输功率
		tmax = np.argmax(tmm[0])  # 结束最晚的机器

		C_finish = max(tmm[0])  # 最晚完工时间
		Twork = sum(tmmw[0])  # 机器负荷

		return C_finish, E_all, Twork, tmax, list_T, list_M, list_S, list_W, tmmw, Wmax
	def plugin(self,list_T,list_M,list_S,list_W,job,tmmw,trantime):
			# print(job)
			p1, p2 = [], []
			# print(type(job))
			job=job.tolist()
			# print(type(job))
			for i in range(self.machine_num):
				p1.append(self.M_dicr[i][1])
				p2.append(self.M_dicr[i][2])

			for i in range(self.machine_num):
				for j in range(len(list_T[i])):

					if (list_T[i][j][1]>1) and (j>0):
						a,b=int(list_T[i][j][0]),int(list_T[i][j][1])-1

						# print("-----------------------")
						for x in range(len(list_T)):
							for y in range(len(list_T[x])):
								if (list_T[x][y][0]==a) and (list_T[x][y][1]==b):
									for z in range(j-1):
										if (list_T[x][y][2]+list_T[x][y][3]+list_T[i][j][4]<=list_T[i][z][2]+list_T[i][z][3]) and (list_T[i][z][2]+list_T[i][z][3]+list_T[i][j][3]<=list_T[i][z+1][2]):
											# print(list_T[x][y][2]+list_T[x][y][3])
											# print("----")
											# print(list_T[i][j])
											list_T[i][j][2]=list_T[i][z][2]+list_T[i][z][3]
											list_T[i].insert(z+1,list_T[i][j])
											# print(list_T[i][j+1])
											del list_T[i][j+1]

											this_job=self.getind(list_T[i][z+1],job)
											next_job=self.getind(list_T[i][z+2],job)

											# print(this_job, next_job)
											# print("---")
											job[0].insert(next_job,job[0][this_job])
											del job[0][this_job+1]



											# print(z)
											# print(j)
											#
											# print(list_T)
											# print("------------------")
											break
										elif (list_T[x][y][2]+list_T[x][y][3]<=list_T[i][z][2]+list_T[i][z][3]) and (list_T[x][y][2]+list_T[x][y][3]+list_T[i][j][4]>=list_T[i][z][2]+list_T[i][z][3]) and (list_T[x][y][2]+list_T[x][y][3]+list_T[i][j][4]+list_T[i][j][3]<=list_T[i][z+1][2]):
											list_T[i][j][2] = list_T[x][y][2] + list_T[x][y][3]+list_T[i][j][4]
											# print(list_T[i][j])
											# print("------------------")
											list_T[i].insert(z + 1, list_T[i][j])

											del list_T[i][j + 1]
											this_job = self.getind(list_T[i][z + 1], job)
											next_job = self.getind(list_T[i][z + 2], job)
											job[0].insert(next_job,job[0][this_job])
											del job[0][this_job + 1]

											# print(list_T)
											break
										elif (list_T[x][y][2]+list_T[x][y][3]>=list_T[i][z][2]+list_T[i][z][3]) and (list_T[x][y][2]+list_T[x][y][3]+list_T[i][j][4]+list_T[i][j][3]<=list_T[i][z+1][2]):
											list_T[i][j][2] = list_T[x][y][2] + list_T[x][y][3] + list_T[i][j][4]
											# print(list_T[i][j])
											# print(list_T[x][y])
											# print("------------------")
											list_T[i].insert(z + 1, list_T[i][j])

											del list_T[i][j + 1]
											this_job = self.getind(list_T[i][z + 1], job)
											next_job = self.getind(list_T[i][z + 2], job)

											job[0].insert(next_job,job[0][this_job])

											del job[0][this_job + 1]

											# print(list_T)
											break
										elif (j==len(list_T[i]) and list_T[x][y][2]+list_T[x][y][3]+list_T[i][j][4]>=list_T[i][z][2]+list_T[i][z][3]):
											list_T[i][j][2]=list_T[x][y][2]+list_T[x][y][3]
											break
										elif (j==len(list_T[i]) and list_T[x][y][2]+list_T[x][y][3]+list_T[i][j][4]<=list_T[i][z][2]+list_T[i][z][3]):
											list_T[i][j][2] = list_T[i][z][2] + list_T[i][z][3]
											break

			job=np.array(job)

			tmm = np.zeros((1, self.machine_num))
			ind= np.zeros((1, self.job_num))
			list_M, list_S, list_W, = [], [], []
			for i in range(job.shape[1]):
				x = int(job[0, i])
				ind[0, int(job[0][i])] += 1
				y=int(ind[0, int(job[0][i])])
				# print(type(y))
				# print(y)
				# print(x)
				for j in range(len(list_T)):
					for k in range(len(list_T[j])):
						if(list_T[j][k][0]==x) and (list_T[j][k][1]==y):
							list_S.append(list_T[j][k][2])
							list_M.append(j)
							list_W.append(list_T[j][k][3])
							tmm[0,j]=max(list_T[j][k][2]+list_T[j][k][3],tmm[0,j])

			# print(tmm)
			# print(jobtime)
			# print(list_S)
			# print(list_W)
			# print(tmm)
			# print(tmmw)
			# print("-----------------")
			# print(job)
			# print("-----------------")
			# print(list_T)

			trest = tmm - tmmw
			E_all = sum((tmmw * p1)[0]) + sum((trest * p2)[0 - 1]) +sum((trantime*0.5)[0])#加工功率+空载功率+运输功率
			tmax=np.argmax(tmm[0])+1		#结束最晚的机器
			C_finish=max(tmm[0])			#最晚完工时间
			Twork = sum(tmmw[0])  # 机器负荷
			# print(C_finish)
			# print("-----------------")
			return C_finish,Twork,E_all,list_M,list_S,list_W,tmax,list_T



	def displaced(self,job,machine,machine_time,trantime,WC,list_T,out_p,To,Tr):   #WC从1开始
		tx = 0
		temp = 0
		for i in range(0,len(list_T)):
			for j in range(0,len(list_T[i])):
				if ((list_T[i][j][2] >= To + Tr) or (list_T[i][j][2] + list_T[i][j][3] <= To)) or list_T[i][j][5] != out_p:#正确的区间
					tx = tx + 1
					continue

				jo = list_T[i][j][0]  # j从0开始
				temp = temp + 1
				index = list_T[i][j][1]  # 从1开始 工序号
				inde = list_T[i][j][1]
				for z in range(0, len(self.work)):
					if job[0][z] == jo:
						if index == 1:
							WC[0,z]= self.select_different_number1(self.work_arr[i],WC[0,z])


						else:
							index = index - 1






		return WC,temp
	def draw(self,job,machine,machine_time,trantime,wc,WC_W1):#画图
				# C_finish,list_M,list_S,list_W,tmax=self.caculate(job,machine,machine_time,trantime)
				C_finish,Twork,E_all, T, M, S, W,tmmw=self.caculate(job,machine,machine_time,trantime,wc)
				C_finish,Twork,E_all,list_M,list_S,list_W,tmax,list_T = self.plugin(T, M, S, W, job, tmmw,trantime)
				# list_M1,list_S1,list_W1,job1=[],[],[],[]
				plt.figure(figsize=(20, 10))
				fa = [[] for i in range(len(self.tran_time))]
				for i in range(self.machine_num):
					fa[self.M_dicr[i][0] - 1].append(i)
				# print("fa=",fa)
				ga = []

				for i in range(len(fa)):
					for j in range(len(fa[i])):
						ga.append(fa[i][j])

				# print(ga)
				tran2 = [0]
				zz = 0
				for i in range(len(fa) - 1):
					zz = zz + len(fa[i])
					tran2.append(zz)
				# print(tran2)
				colors = ['red', 'Navy', 'grey', 'yellow', 'Violet', 'Cyan', 'Green', 'LightYellow', 'Tan', 'Coral',
						  'SlateBlue', 'DeepSkyBlue', 'DarkCyan', 'SeaGreen', 'OliveDrab', 'Orange', 'LightSalmon',
						  'Tomato', 'RosyBrown', 'Linen', 'Wheat', 'Turquoise', 'PowderBlue', 'CornflowerBlue',
						  'Thistle', 'Teal', 'MintCream', 'Chartreuse', 'OliveDrab', 'Goldenrod', 'red', 'Navy', 'grey',
						  'yellow', 'Violet', 'Cyan', 'Green', 'LightYellow', 'Tan', 'Coral', 'SlateBlue',
						  'DeepSkyBlue', 'DarkCyan', 'SeaGreen', 'OliveDrab', 'Orange', 'LightSalmon', 'Tomato',
						  'RosyBrown', 'Linen', 'Wheat', 'Turquoise', 'PowderBlue', 'CornflowerBlue', 'Thistle', 'Teal',
						  'MintCream', 'Chartreuse', 'OliveDrab', 'Goldenrod', 'red', 'Navy', 'grey', 'yellow',
						  'Violet', 'Cyan', 'Green', 'LightYellow', 'Tan', 'Coral', 'SlateBlue', 'DeepSkyBlue',
						  'DarkCyan', 'SeaGreen', 'OliveDrab', 'Orange', 'LightSalmon', 'Tomato', 'RosyBrown', 'Linen',
						  'Wheat', 'Turquoise', 'PowderBlue', 'CornflowerBlue', 'Thistle', 'Teal', 'MintCream',
						  'Chartreuse', 'OliveDrab', 'Goldenrod']

				for i in range(self.job_num):
					for j in range(len(list_T)):
						for z in range(len(list_T[j])):
							if list_T[j][z][0] == i:
								ind = ga.index(j)
								# print(ind)
								plt.bar(x=list_T[j][z][2], bottom=ind, height=0.5, width=list_T[j][z][3],
										orientation="horizontal", color=colors[i], edgecolor='black')

								plt.text(list_T[j][z][2] + list_T[j][z][3] / 32, ind, '%.0f' % (i + 1), color='black',
										 verticalalignment='center', fontsize=12, weight='bold')  # 12是矩形框里字体的大小，可修改
								#print(list_T[j][z])
								#print(WC_W1[i])
								#print("@@@")
								plt.text(list_T[j][z][2] + list_T[j][z][3] / 32, ind,
										 '%.0f' % (WC_W1[i][int(list_T[j][z][1] - 1)]), color='black',
										 verticalalignment='bottom', fontsize=12, weight='bold')
								if list_T[j][z][4] != 0:
									plt.bar(x=list_T[j][z][2] - list_T[j][z][4], bottom=ind + 0.3, height=0.1,
											width=list_T[j][z][4], orientation="horizontal", color=colors[i],
											edgecolor='black')

				for i in range(len(fa)):
					plt.text(C_finish + 1, tran2[i], 'FACTORY%.0f' % (i + 1), color='black', verticalalignment='center',
							 fontsize=20, weight='bold')  # 12是矩形框里字体的大小，可修改
				# plt.bar(x=C_finish+1, bottom=tran2[i], height=0.5, width=50, orientation="horizontal",color='white', edgecolor='blue')
				# plt.plot([C_finish, C_finish], [0, tran2[i]], c='black', linestyle='-.',label='Factory%.1f' % (i+1))  # 用虚线画出最晚完工时间
				font1 = {'weight': 'bold', 'size': 22}  # 汉字字体大小，可以修改

				plt.xlabel("Time", font1)
				# plt.title("of1", font1)
				plt.ylabel("Machine", font1)
				scale_ls, index_ls = self.axis()
				tran = []
				aaa = 0
				for i in range(len(fa) - 1):
					aaa = aaa + len(fa[i])
					tran.append(aaa)
				yticks = [scale_ls[i] for i in ga]
				# print(yticks)
				plt.yticks([i for i in range(0, self.machine_num)], yticks)

				plt.hlines([float(i - 0.5) for i in tran], 0, C_finish, color="blue")  # 横线
				plt.tick_params(labelsize=22)  # 坐标轴刻度字体大小，可以修改
				plt.plot([C_finish, C_finish], [0, tmax + 1], c='black', linestyle='-.',
						 label='Finish time=%.1f' % (C_finish))  # 用虚线画出最晚完工时间

				ax = plt.gca()
				labels = ax.get_xticklabels()
				[label.set_fontname('Times New Roman') for label in labels]
				plt.legend(prop={'family': ['SimHei'], 'size': 16})  # 标签字体大小，可以修改
				plt.xlabel("Time", font1)
				plt.savefig('GTT.png')
				plt.show()

	def select_different_number(self, list, number):
		while True:
			if len(list) == 1:
				return number, 0
			else:
				random_number = np.random.choice(list)
				random_index = list.index(random_number)
				if random_number != number:
					return random_number, random_index

	def select_different_number1(self, list, number):
		while True:
			if len(list) == 1:
				return number
			else:
				random_number = np.random.choice(list)
				if random_number != number:
					return random_number

	def find_time(self, List_T, job_id, gx_id):
		for i in range(0, self.machine_num):
			for j in range(0, len(List_T[i])):

				if List_T[i][j][0] == job_id and List_T[i][j][1] == gx_id:
					return List_T[i][j][2] + List_T[i][j][3]










	def breakdown(self,job,machine,machine_time,trantime,WC,List_T,Machine,To,Tr):   #job machine machine_time 为1*n的np数组
		Machine1 = int(Machine)-1
		Ra = 0.5
		Rb = 0.3
		Rc = 0.2
		temp =0


		for i in range(0,len(List_T[Machine1])):
			if(List_T[Machine1][i][2])>=To +Tr or (List_T[Machine1][i][2] + List_T[Machine1][i][3]<=To):
				continue
			#else:
			j = List_T[Machine1][i][0]   #j从0开始
			temp = temp+1
			index = List_T[Machine1][i][1]  #从1开始
			inde =List_T[Machine1][i][1]
			for z in range(0,len(self.work)):
				if job[0][z] == j:
					if index == 1:
						Ro = random.random()
						if Ro <=Ra:
							Mac_cho = self.Tmachine[j][inde-1]
							for ma in Mac_cho:
								ma =ma - 1
								if ma ==Machine1:
									continue
								#else:
								ind = Mac_cho.index(ma+1)

								for t in range(0,len((List_T[ma]))):
									if List_T[ma][t][2] >= To:
										break
									gx_comp = self.find_time(List_T,j,inde)
									if List_T[ma][t][2] - self.Tmachinetime[j][inde -1][ind] >= List_T[ma][t-1][2]+List_T[ma][t-1][3] and List_T[ma][t][2] - self.Tmachinetime[j][inde -1][ind] >= gx_comp:
										machine[0,z] = ma
										machine_time[0,z] = self.Tmachinetime[j][inde-1][ind]
										WC[0,z],tx = self.select_different_number(self.work_arr[int(machine[0,z]-1)],WC[0,z])


						if Ro >Ra and Ro <= Ra + Rb:
							ind = np.argmin(self.Tmachinetime[j][inde-1])
							if machine[0,z] == self.Tmachine[j][inde-1][ind]:
								ind = np.argsort(self.Tmachinetime[j][inde-1])
								machine[0,z] =self.Tmachine[j][inde-1][ind[1]]-1
								machine_time[0,z]= self.Tmachinetime[j][inde-1][ind[1]]
								WC[0, z], tx = self.select_different_number(self.work_arr[int(machine[0, z] - 1)],
																			WC[0, z])
							else:
								machine[0,z] = self.Tmachine[j][inde-1][ind]-1
								machine_time[0, z] = self.Tmachinetime[j][inde - 1][ind]
								WC[0, z], tx = self.select_different_number(self.work_arr[int(machine[0, z] - 1)],
																			WC[0, z])




						if Ro > Ra + Rb and Ro <= Ra + Rb +Rc :
							machine[0,z],ind=self.select_different_number(self.Tmachine[j][inde-1],machine[0,z]+1)    #变成-1了
							machine[0,z] = machine[0,z]-1
							machine_time[0,z] = self.Tmachinetime[j][inde-1][ind]
							machine_time[0,z] = machine_time[0,z]

							WC[0,z],tx= self.select_different_number(self.work_arr[int(machine[0,z]-1)],WC[0,z])
					else:
						index=index-1








		return machine,machine_time,trantime,WC,temp

# oj=data_deal()
# # Tmachine,Tmachinetime,tdx,work,tom=oj.cacu()
# Tmachine,Tmachinetime,tdx,work,tom,int2,M,M_dicr, tran_time=oj.cacu()
# #print(Tmachine)
# # # # print(Tmachinetime)
# parm_data=[Tmachine,Tmachinetime,tdx,work,M_dicr, tran_time]
# # # to=FJSP(10,6,0.5,parm_data)
# # print(parm_data)
# to=FJSP(25,10,0.5,parm_data)
# job,machine,machine_time,initial_a,trantime=to.creat_job()
# # #
# # print(trantime)
# _, _, list_T, list_M, list_S, list_W, tmmw = to.caculate(job, machine, machine_time, trantime)
# C_finish, Twork, E_all, _, _, _, _ = to.plugin(list_T, list_M, list_S, list_W, job, tmmw,trantime)
# print(C_finish)
# print(list_M)
# print(job)
# to.draw(job,machine,machine_time,trantime)

#
# # print(C_finish)
# to.draw(job,machine,machine_time)