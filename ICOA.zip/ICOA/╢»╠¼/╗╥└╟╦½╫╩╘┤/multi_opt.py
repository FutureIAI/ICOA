import numpy as np
import math
# import matplotlib.pyplot as plt
# plt.rcParams['font.sans-serif'] = ['SimHei'] 

import matplotlib.pyplot as plt
from matplotlib.pylab import mpl

mpl.rcParams['font.sans-serif'] = ['SimHei']  # 添加这条可以让图形显示中文
from mpl_toolkits.mplot3d import axes3d


class mul_op():


    def divide(self, answer):
        S = [[] for i in range(len(answer))]

        front = [[]]

        n = [0 for i in range(len(answer))]
        rank = [0 for i in range(len(answer))]
        for p in range(len(answer)):
            for q in range(len(answer)):
                # 如果p支配q
                if (np.array(answer[p]) <= np.array(answer[q])).all() and (answer[p] != answer[q]):
                    if q not in S[p]:
                        S[p].append(q)  # 同时如果q不属于sp将其添加到sp中
                # 如果q支配p
                elif (np.array(answer[p]) >= np.array(answer[q])).all() and (answer[p] != answer[q]):
                    n[p] = n[p] + 1  # 则将np+1
            if n[p] == 0:
                rank[p] = 0
                if p not in front[0]:
                    front[0].append(p)
        i = 0

        while front[i] != []:
            Q = []
            for p in front[i]:
                for q in S[p]:
                    n[q] = n[q] - 1  # 则将fk中所有给对应的个体np-1
                    if n[q] == 0:  # 如果nq==0
                        rank[q] = i + 1
                        if q not in Q:
                            Q.append(q)
            i = i + 1

            front.append(Q)



        del front[len(front) - 1]

        return front

    def dis(self, answer):
        crowder, crowd = [], []
        front = self.divide(answer)
        # print(front)
        # print(len(front))
        for i in range(len(front)):

            x = [answer[front[i][j]][0] for j in range(len(front[i]))]  # 取三个目标函数的各个目标
            y = [answer[front[i][j]][1] for j in range(len(front[i]))]
            z = [answer[front[i][j]][2] for j in range(len(front[i]))]
            f = [answer[front[i][j]][3] for j in range(len(front[i]))]
            sig = front[i]
            clo = [[] for j in range(len(front[i]))]
            if (len(sig) > 1):  # 每层的个体大于1个做拥挤度计算
                x_index, y_index, z_index, f_index = np.array(x).argsort(), np.array(y).argsort(), np.array(
                    z).argsort(), np.array(f).argsort()
                x.sort(), y.sort()
                z.sort(), f.sort()
                dis1, dis2, dis3, dis4 = [], [], [], []
                dis1.append(100000)
                dis2.append(100000)
                dis3.append(100000)
                dis4.append(100000)
                if (len(sig) > 2):  # 大于2个做中间个体的拥挤度计算
                    for k in range(1, len(sig) - 1):
                        # print(y)
                        if (x[-1] == x[0]):
                            distance1 = 0
                        else:
                            distance1 = (x[k + 1] - x[k - 1]) / (x[-1] - x[0])
                        if (y[-1] == y[0]):
                            distance2 = 0
                        else:
                            distance2 = (y[k + 1] - y[k - 1]) / (y[-1] - y[0])
                        if (z[-1] == z[0]):
                            distance3 = 0
                        else:
                            distance3 = (z[k + 1] - z[k - 1]) / (z[-1] - z[0])
                        if (f[-1] == f[0]):
                            distance4 = 0
                        else:
                            distance4 = (f[k + 1] - f[k - 1]) / (f[-1] - f[0])
                        # distance1, distance2, distance3, distance4= (x[k + 1] - x[k - 1]) / (x[-1] - x[0]), (y[k + 1] - y[k - 1]) / (y[-1] - y[0]), (z[k + 1] - z[k - 1]) / (z[-1] - z[0]),(f[k + 1] - f[k - 1]) / (f[-1] - f[0])
                        dis1.append(distance1)
                        dis2.append(distance2)
                        dis3.append(distance3)
                        dis4.append(distance4)
                dis1.append(100001)
                dis2.append(100001)
                dis3.append(100001)
                dis4.append(100001)
                crow = []
                x_index = x_index.tolist()
                y_index = y_index.tolist()
                z_index = z_index.tolist()
                f_index = f_index.tolist()
                for m in range(len(sig)):
                    index1, index2, index3, index4 = x_index.index(m), y_index.index(m), z_index.index(
                        m), f_index.index(m)
                    cro = dis1[index1] + dis2[index2] + dis3[index3] + dis4[index4]
                    crow.append(cro)
                crowd.append(crow)
                index = np.array(crow).argsort()
                for n in range(len(index)):  # 拥挤度排列并取出
                    clo[n] = sig[index[n]]
                for o in range(len(clo) - 1, -1, -1):
                    crowder.append(clo[o])

            else:
                crowder.append(front[i][0])
                crowd.append([1])
        return front, crowd, crowder  # 分级然后计算拥挤度并排序




    def draw_change(self, fit_every):
        plt.figure(figsize=(20, 6))
        font1 = {'weight': 'normal', 'size': 22}
        legend = ['最小完工时间', '最大负荷', '最小能耗']
        title = ['完工时间变化图', '机器负荷变化图', '能耗变化图']
        # print(fit_every)
        for i in range(3):
            plt.subplot(1, 3, i + 1)
            x = [fit_every[i][j][0] for j in range(len(fit_every[i]))]
            # y = [fit_every[i][j][1] for j in range(len(fit_every[i]))]
            # z = [fit_every[i][j][2] for j in range(len(fit_every[i]))]
            # print(y)
            plt.plot(fit_every[3], x, c='black', linestyle='-', label=legend[i])  # 作h1函数图像
            # plt.plot(fit_every[3], y, c='black', linestyle='--')
            # plt.plot(fit_every[3], z, c='black', linestyle='-.')
            plt.xlabel('迭代次数', font1)
            plt.title(title[i], font1)
            plt.legend(loc='upper right', fontsize=20)
            plt.tick_params(labelsize=18)
        plt.savefig('zx.png')
        plt.show()


    def draw_3d(self, pareto):
        fig = plt.figure()
        # ax = fig.add_subplot(111, projection='3d')
        ax = fig.add_subplot(111, projection='3d')
        x = [pareto[i][0] for i in range(len(pareto))]
        y = [pareto[i][1] for i in range(len(pareto))]
        z = [pareto[i][2] for i in range(len(pareto))]

        ax.scatter(x, y, z, c='red', s=20)
        font1 = {'weight': 'bold', 'size': 16}
        ax.set_xlabel("完工时间", font1)
        ax.set_ylabel("机器负荷", font1)
        ax.set_zlabel("能耗", font1)
        plt.savefig('3d.png')
        plt.show()


# oh = mul_op
