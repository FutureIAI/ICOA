import json
import numpy as np
import re
class data_deal:
    # def __init__(self):
        # self.job_num = job_num
        # self.machine_num = machine_num
        # "job":每个工件的工序在不同机器上处理的时间
        # "M"：机器数量
        # "job_num"：每个工件工序数量
        # "O"：总工序数
        # "J"：总工件数
        # "F", 总工厂数
        #"M_max",每个工厂最大机器数
        # “energy”，工序在对应机器的对应能耗

    def read(self):
        f = open('DFM02_10x2x6.txt')
        f1 = f.readlines()
        c, count = [], 0
        qus_num=[]
        for line in f1:
            t1 = line.strip('\n')
            if (0<count<5):
                qus = re.sub("\D", "", t1)
                qus_num.append(int(qus))
            # print(t1)
            if (count > 4):
                sig = 0
                cc = []
                for j in range(len(t1)):

                    if (t1[j] == ' '):
                        cc.append(int(t1[j - sig:j]))
                        sig = 0
                    if (t1[j] != ' '):
                        sig += 1
                    # if (j == len(t1) - 1):
                    #     cc.append(int(t1[j]))
                    #     sig = 0
                c.append(cc)
            count += 1
        J=qus_num[0]
        F=qus_num[1]
        M=qus_num[1]*qus_num[2]
        M_max=qus_num[2]
        O=J*c[0][0]
        return c,J,F,M,M_max,O

    def translate(self, tr1,F,M_max):
        sigdex, mac, mact,macten, sdx,fato = [], [], [], [],[],[]
        sigal = tr1[0]#工序数
        tr1 = tr1[1:len(tr1) + 1]
        # print(tr1)
        # print(len(tr1))
        fadx=[]
        index = 0
        inde = 1
        for j in range(sigal):
            sig = tr1[index]#可加工机器数
            sag=tr1[inde]#是工厂标号
            for ij in range(sig):
                sag = tr1[inde]
                if sag<=F and tr1[inde+1]<= M_max*F:
                    fadx.append(inde)
                    inde=inde+4
                elif sag>F or tr1[inde+1] > M_max:
                    inde=inde+3
                    fadx.append(fadx[-1])
            sigdex.append(index)
            index=inde
            inde=index+1
            sdx.append(sig)

        for jj in range(len(fadx)):
            fato.append(tr1[fadx[jj]])

        add=sigdex+fadx
        tr1 = [n for ii, n in enumerate(tr1) if ii not in add]

        for k in range(0,len(tr1)-1,3):
            mac.append(tr1[k])#机器号
            mact.append(tr1[k+1])#加工时间
            macten.append(tr1[k+2])#加工能耗
        # print(mac)
        # print(mact)
        # print(macten)
        # print(sdx)
        # print(fato)
        return mac,mact,macten,sdx,fato
    def tcaculate(self, strt,F,M_max):
        width = strt[0][0]
        Factory,Tmachine, Tmachinetime,Tmachinehn = [[]for i in range(J)],[[]for i in range(J)],[[]for i in range(J)],[[]for i in range(J)]
        tdx = []
        for i in range(J):
            mac,mact,macten,sdx,fato = self.translate(strt[i],F,M_max)
            tdx.append(sdx)
            ma,mat,maten,mafa=[],[],[],[]
            z = 0
            for j in range(width):

                for k in range(sdx[j]):
                    mafa.append(fato[z])
                    ma.append(mac[z])
                    mat.append(mact[z])
                    maten.append(macten[z])
                    z+=1
                Tmachine[i].append(ma)
                Tmachinetime[i].append(mat)
                Tmachinehn[i].append(maten)
                Factory[i].append(mafa)
                ma,mat,maten,mafa=[],[],[],[]


        return Tmachine, Tmachinetime,Tmachinehn, Factory,tdx

    def cacu(self):
        strt,J,F,M,M_max,O = self.read()
        Tmachine, Tmachinetime,Tmachinehn, Factory,tdx = self.tcaculate(strt,F,M_max)
        to, tom, work = 0, [], []
        for i in range(J):
            to += len(tdx[i])
            tim = []
            for j in range(1, len(tdx[i]) + 1, 1):
                tim.append(sum(tdx[i][0:j]))
                work.append(i)
            tom.append(tim)
        return Tmachine, Tmachinetime, Tmachinehn, Factory,tdx, work, tom
to=data_deal()
c,J,F,M,M_max,O=to.read()
# print(c,J,F,M,M_max,O)
# print(type(J))
Tmachine, Tmachinetime, Tmachinehn, Factory,tdx, work, tom=to.cacu()
print(tdx)#工序对应的可使用机器数
print(work)#每个工件对应的工序，按工件索引排列

print(tom)#该工件按工序排列可使用的机器数和
print(Tmachine)#机器号
print(Tmachinetime)#加工时间
print(Tmachinehn)#加工能耗
print(Factory)#加工所在工厂
