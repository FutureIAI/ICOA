import random

t=[1,4,6,7,8,3,0,0,0,0]
time=[1,0,0,0,0,0,0,0,0,0]
a=random.sample(t, 2)
# print(ind[-1])
print(a)