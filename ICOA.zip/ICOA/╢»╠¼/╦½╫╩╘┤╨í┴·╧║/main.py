from small_work import data_deal
from fjsp import FJSP
from multi_opt import mul_op
from GWO import gwo
import numpy as np
import  math
from pymoo.indicators.hv import Hypervolume
def distanse(x, y):
    return math.sqrt(sum([pow(a - b, 2) for a, b in zip(x, y)]))


def get_IGD(c, a):
    return sum([min([distanse(i, j) for j in a]) for i in c])
def tmain():
    oj = data_deal()
    item_ = oj.item
    job_num = item_["int2"]
    machine_num = item_["M"]

    # oj=data_deal(10,6)               #工件数，机器数
    Tmachine, Tmachinetime, tdx, work, tom,int1, int2, M, M_dicr, tran_time,worker,work_num = oj.cacu()
    parm_data = [Tmachine, Tmachinetime, tdx, work, M_dicr, tran_time,int1,worker,work_num]
    # to=FJSP(10,6,0.5,parm_data)      #工件数，机器数，选择最短机器的概率和mk01的数据
    print(work)
    to = FJSP(job_num, machine_num, 0.5, parm_data,100)
    #_, _, _, _, _ = to.creat_job()
    oh = mul_op()
    ho = gwo(100,100, to, oh, work, job_num,tran_time,M_dicr,parm_data[7])  # 数50,100,10分别代表迭代的次数、种群的规模、机器数
    print()
    # to是柔性车间模块，oh是多目标模块

    pareto, pareto_job, pareto_machine, pareto_time, pareto_tran, fit_every,pareto_WC = ho.gwo_total()  # 最后一次迭代的最优解
    print(pareto)
    sig = 0
    job, machine = np.array([pareto_job[sig]]), np.array([pareto_machine[sig]])
    machine_time = np.array([pareto_time[sig]])
    trantime = np.array([pareto_tran[sig]])
    wc = np.array([pareto_WC[sig]])
    C_finish, _, _, list_T, list_M, list_S, list_W, tmmw,= to.caculate(job, machine, machine_time, trantime,
                                                                          wc)  # np.array([WC[i]]))

    C_finish, Twork, E_all, _, _, _, _,_=to.plugin(list_T, list_M, list_S, list_W, job, tmmw, trantime)

    # print(fit_every)
    Ma_W1, Tm_W1, WCross,Tr_W1, WC_W1 = ho.to_MT(job, machine, machine_time,trantime, wc)


    # to.draw(job, machine, machine_time, trantime,wc,WC_W1)
    # oh.draw_change(fit_every)  # 每次迭代过程中pareto解中3个目标的变化
    # oh.draw_3d(pareto)
    print(fit_every)
    return pareto,oh,to,pareto_job, pareto_machine, pareto_time, pareto_tran, fit_every

#
def compute():
    PFture=[]
    temp1 = 0
    temp2 = 0
    for i in range(20):
        paretoture,_,_,_,_,_,_,_,=tmain()
        # temp1 = temp1 + IGD
        # temp2 = temp2 + HV
        PFture.extend(paretoture)
    # IGD = temp1/20
    # HV = temp2/20
    # print("IGD=",IGD)
    # print("hv=",HV)
    answer = PFture
    front,crowd,crowder =mul_op().dis(answer)
    sig = front[0]
    b =np.array(answer)[sig].tolist()
    #
    #
    #
    #
    # # # PFture=[[375.0, 1940.0, 32394.730944617713], [312.0, 2081.0, 34042.852756537366], [360.0, 2061.0, 34438.42555761163], [364.0, 1997.0, 34244.22040910855], [562.0, 2010.0, 36732.73252635713], [353.0, 2201.0, 36588.549099432465], [373.0, 2087.0, 33699.40077861737], [465.0, 2023.0, 34453.157134821784], [415.0, 2039.0, 34282.342834087176], [338.0, 2017.0, 33319.29796571557], [460.0, 1974.0, 33355.01592524815], [449.0, 1999.0, 34402.370159790094], [409.0, 1988.0, 34547.198352961364], [333.0, 2008.0, 33478.23958477824], [401.0, 2004.0, 33898.95838006032], [333.0, 2025.0, 33691.11555913418], [452.0, 1918.0, 33490.28454257752], [363.0, 1969.0, 32763.6494383678], [431.0, 1984.0, 31867.9570240595], [386.0, 1902.0, 32368.55551327787], [325.0, 1913.0, 31978.58760905866], [334.0, 2163.0, 35542.596772969984], [394.0, 2009.0, 32591.975488451728], [376.0, 1936.0, 33199.32348024244], [483.0, 1932.0, 33755.96887564953], [332.0, 2138.0, 35302.480255448645], [381.0, 2076.0, 36360.1553508989], [367.0, 2125.0, 35512.161239963345], [443.0, 2018.0, 34584.49260195217], [397.0, 2022.0, 33764.55003993884], [453.0, 1998.0, 35387.84623429261], [386.0, 2053.0, 34998.031345326155], [441.0, 1894.0, 32265.54601310904], [337.0, 2155.0, 35198.229094313254], [375.0, 2080.0, 35966.36039570767], [408.0, 1974.0, 33188.81394497445], [326.0, 2035.0, 33263.69464461051], [471.0, 1960.0, 32988.013307293964]]
    # # # for sig in range(len(pareto)):
    #
    IGD = 0
    ob1, ob2, ob3, ob4 = [], [], [], []
    for i in range(len(PFture)):
        ob1.append(PFture[i][0])
        ob2.append(PFture[i][1])
        ob3.append(PFture[i][2])
        ob4.append(PFture[i][3])
    max1, min1, max2, min2, max3, min3, max4, min4 = max(ob1), min(ob1), max(ob2), min(ob2), max(ob3), min(ob3), max(
        ob4), min(ob4)
    maxob = [max1, max2, max3]
    minob = [min1, min2, min3]
    for i in range(len(PFture)):
        di = []
        for j in range(len(b)):
            diff = 0
            for ob in range(3):
                fz1 = (b[j][ob] - minob[ob]) / (maxob[ob] - minob[ob])
                # print(fz1)
                fz2 = (PFture[i][ob] - minob[ob]) / (maxob[ob] - minob[ob])
                # print(fz1,fz2)
                diff = diff + pow(fz2 - fz1, 2)
            di.append(diff)

        d = min(di)
        # print(d)
        IGD = IGD + math.sqrt(d)
        # print(IGD)
    IGD = IGD / len(PFture)
    print("IGD=", IGD)
    print(b)
    # IGD.append(IGD1)

    PF = b

    ob1, ob2, ob3, ob4 = [], [], [], []
    for i in range(len(PFture)):
        ob1.append(PFture[i][0])
        ob2.append(PFture[i][1])
        ob3.append(PFture[i][2])
        ob4.append(PFture[i][3])
    max1, min1, max2, min2, max3, min3, max4, min4 = max(ob1), min(ob1), max(ob2), min(ob2), max(ob3), min(ob3), max(
        ob4), min(ob4)
    maxob = [max1, max2, max3, max4]
    minob = [min1, min2, min3, min4]
    for i in range(len(PF)):
        for j in range(3):
            PF[i][j] = (PF[i][j] - minob[j]) / (maxob[j] - minob[j])
            # fz2=(PFture[i][0]-min1)/(max1-min1)
    print(PF)
    # for i in range (len(PFture)):
    #     x.append(PFture[i][0])
    #     y.append(PFture[i][1])
    #     z.append(PFture[i][2])
    # x1=max(x)
    # y1=min(y)
    # z1=max(z)
    ref = [1.01, 1.01, 1.01, 1.01]
    print(ref)
    PF.sort(key=lambda ele: ele[0], reverse=True)  # 按第一个元素降序排序
    ind = np.zeros(len(PF))

    a = []
    for i in range(len(PF)):
        for j in range(len(PF)):
            if (PF[i][0] <= PF[j][0] and PF[i][1] <= PF[j][1] and PF[i][2] <= PF[j][2] and PF[i][3] <= PF[j][3]) and (
                    PF[i][0] < PF[j][0] or PF[i][1] < PF[j][1] or PF[i][2] < PF[j][2] or PF[i][3] < PF[j][3]):
                ind[j] += 1
    for i in range(len(ind)):
        if ind[i] == 0:
            a.append(PF[i])
    print(a)
    # print(type(a[0]))
    # a=[1.01,1.01,1.01]
    b = a.copy()
    b = np.array(b)
    hv_indicator = Hypervolume(ref_point=ref)
    hv = hv_indicator.do(b)
    # b = a.copy()
    # HV = 0
    # area = 0
    # for i in range(len(a)):
    #     if i == 0:
    #         depth = ref[0] - a[i][0]
    #     else:
    #         depth = a[i - 1][0] - a[i][0]
    #         b.remove(a[i - 1])
    #     b.sort(key=lambda ele: ele[1], reverse=False)
    #     for j in range(len(b)):
    #         if j == 0:
    #             depth1 = abs(b[j][1] - ref[1])
    #         else:
    #             depth1 = abs(b[j][1] - b[j - 1][1])
    #         area = area + depth1 * abs(ref[2] - b[j][2])
    #     # print(area)
    #
    #     HV = HV + area * depth

    print("hv=", hv)
    return IGD, hv

temp1,temp2 = 0,0
for i in range(20):
    igd,hv = compute()
    temp1 = temp1 + igd
    temp2 = temp2 + hv
print("IGD=",temp1/20)
print("HV=",temp2/20)




# # PFture=[[375.0, 1940.0, 32394.730944617713], [312.0, 2081.0, 34042.852756537366], [360.0, 2061.0, 34438.42555761163], [364.0, 1997.0, 34244.22040910855], [562.0, 2010.0, 36732.73252635713], [353.0, 2201.0, 36588.549099432465], [373.0, 2087.0, 33699.40077861737], [465.0, 2023.0, 34453.157134821784], [415.0, 2039.0, 34282.342834087176], [338.0, 2017.0, 33319.29796571557], [460.0, 1974.0, 33355.01592524815], [449.0, 1999.0, 34402.370159790094], [409.0, 1988.0, 34547.198352961364], [333.0, 2008.0, 33478.23958477824], [401.0, 2004.0, 33898.95838006032], [333.0, 2025.0, 33691.11555913418], [452.0, 1918.0, 33490.28454257752], [363.0, 1969.0, 32763.6494383678], [431.0, 1984.0, 31867.9570240595], [386.0, 1902.0, 32368.55551327787], [325.0, 1913.0, 31978.58760905866], [334.0, 2163.0, 35542.596772969984], [394.0, 2009.0, 32591.975488451728], [376.0, 1936.0, 33199.32348024244], [483.0, 1932.0, 33755.96887564953], [332.0, 2138.0, 35302.480255448645], [381.0, 2076.0, 36360.1553508989], [367.0, 2125.0, 35512.161239963345], [443.0, 2018.0, 34584.49260195217], [397.0, 2022.0, 33764.55003993884], [453.0, 1998.0, 35387.84623429261], [386.0, 2053.0, 34998.031345326155], [441.0, 1894.0, 32265.54601310904], [337.0, 2155.0, 35198.229094313254], [375.0, 2080.0, 35966.36039570767], [408.0, 1974.0, 33188.81394497445], [326.0, 2035.0, 33263.69464461051], [471.0, 1960.0, 32988.013307293964]]
# pareto,oh,to,pareto_job, pareto_machine, pareto_time, pareto_tran, fit_every=tmain()
# # for sig in range(len(pareto)):
# IGD = get_IGD(PFture, pareto)/(len(PFture))
# print(IGD)
# IGD.append(IGD1)

# if len(IGD)>=1:
#     sig1=IGD.index(min(IGD))
# elif len(IGD)==0:
#     sig1=0
# print(IGD)
# exit()
# oh.draw_change(fit_every)        #每次迭代过程中pareto解中3个目标的变化
# oh.draw_3d(pareto)               #结果的3维图

# sig=0
# job,machine=np.array([pareto_job[sig]]),np.array([pareto_machine[sig]])
#
# machine_time=np.array([pareto_time[sig]])
# trantime=np.array([pareto_tran[sig]])
# # print(job)
# #
# # print(machine)
# # print(machine_time)
# # print(trantime)
# to.draw(job,machine,machine_time,trantime)#画pareto解的第一个解的甘特图
